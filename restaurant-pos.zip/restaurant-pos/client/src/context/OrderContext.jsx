import { createContext, useContext, useReducer } from 'react'

const OrderContext = createContext(null)

const initialState = {
  selectedTable: null,
  cart: [],
  orderType: 'dine_in',
  customerName: '',
  waiter: '',
  notes: '',
}

function reducer(state, action) {
  switch (action.type) {
    case 'SET_TABLE': return { ...state, selectedTable: action.payload }
    case 'SET_ORDER_TYPE': return { ...state, orderType: action.payload }
    case 'SET_CUSTOMER': return { ...state, customerName: action.payload }
    case 'SET_WAITER': return { ...state, waiter: action.payload }
    case 'SET_NOTES': return { ...state, notes: action.payload }
    case 'ADD_ITEM': {
      const existing = state.cart.findIndex(i =>
        i.product_id === action.payload.product_id &&
        JSON.stringify(i.modifiers) === JSON.stringify(action.payload.modifiers) &&
        i.notes === action.payload.notes
      )
      if (existing >= 0) {
        const cart = [...state.cart]
        cart[existing] = { ...cart[existing], quantity: cart[existing].quantity + action.payload.quantity }
        return { ...state, cart }
      }
      return { ...state, cart: [...state.cart, { ...action.payload, cartId: Date.now() }] }
    }
    case 'REMOVE_ITEM': return { ...state, cart: state.cart.filter(i => i.cartId !== action.payload) }
    case 'UPDATE_QTY': {
      const cart = state.cart.map(i => i.cartId === action.payload.cartId
        ? { ...i, quantity: Math.max(1, action.payload.qty) } : i)
      return { ...state, cart }
    }
    case 'CLEAR_CART': return { ...initialState }
    default: return state
  }
}

export function OrderProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState)

  const cartSubtotal = state.cart.reduce((sum, i) => {
    const modPrice = i.modifiers?.reduce((s, m) => s + parseFloat(m.price || 0), 0) || 0
    return sum + (i.unit_price + modPrice) * i.quantity
  }, 0)

  const cartTax = cartSubtotal * 0.16
  const cartTotal = cartSubtotal + cartTax
  const cartCount = state.cart.reduce((s, i) => s + i.quantity, 0)

  return (
    <OrderContext.Provider value={{ ...state, dispatch, cartSubtotal, cartTax, cartTotal, cartCount }}>
      {children}
    </OrderContext.Provider>
  )
}

export const useOrder = () => useContext(OrderContext)

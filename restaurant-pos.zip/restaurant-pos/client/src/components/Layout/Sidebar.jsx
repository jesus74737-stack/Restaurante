import { NavLink, useLocation } from 'react-router-dom'
import {
  UtensilsCrossed, LayoutGrid, ClipboardList, ChefHat,
  BarChart3, Settings, Wifi, WifiOff, ShoppingCart
} from 'lucide-react'
import { useSocket } from '../../context/SocketContext'
import { useOrder } from '../../context/OrderContext'

const navItems = [
  { to: '/tables', icon: LayoutGrid, label: 'Mesas' },
  { to: '/menu', icon: UtensilsCrossed, label: 'Menú' },
  { to: '/orders', icon: ClipboardList, label: 'Órdenes' },
  { to: '/kitchen', icon: ChefHat, label: 'Cocina' },
  { to: '/reports', icon: BarChart3, label: 'Reportes' },
  { to: '/admin', icon: Settings, label: 'Admin' },
]

export default function Sidebar() {
  const { connected } = useSocket()
  const { cartCount, selectedTable } = useOrder()

  return (
    <aside className="fixed left-0 top-0 bottom-0 w-16 md:w-20 z-50 flex flex-col items-center py-4"
      style={{ background: '#0A0A0A', borderRight: '1px solid #2A2A2A' }}>

      {/* Logo */}
      <div className="mb-6 flex flex-col items-center">
        <div className="w-10 h-10 rounded-full flex items-center justify-center"
          style={{ background: 'linear-gradient(135deg, #A8860A, #D4AF37, #F0D060)', boxShadow: '0 0 15px rgba(212,175,55,0.4)' }}>
          <UtensilsCrossed size={18} color="#0A0A0A" />
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 flex flex-col gap-1 w-full px-2">
        {navItems.map(({ to, icon: Icon, label }) => (
          <NavLink key={to} to={to}
            className={({ isActive }) => `
              relative flex flex-col items-center justify-center py-3 rounded-xl transition-all duration-200 group
              ${isActive
                ? 'text-black'
                : 'text-gray-500 hover:text-yellow-400'
              }
            `}
            style={({ isActive }) => isActive ? {
              background: 'linear-gradient(135deg, #A8860A, #D4AF37)',
            } : {}}>
            {({ isActive }) => (
              <>
                <Icon size={20} />
                <span className="text-xs mt-1 font-sans hidden md:block"
                  style={{ fontSize: '9px', fontFamily: 'Outfit' }}>
                  {label}
                </span>
                {label === 'Menú' && cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full text-xs flex items-center justify-center font-bold"
                    style={{ background: '#D4AF37', color: '#000', fontSize: '9px' }}>
                    {cartCount}
                  </span>
                )}
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Connection status */}
      <div className="mt-auto flex flex-col items-center gap-1">
        {connected
          ? <Wifi size={14} style={{ color: '#4ade80' }} />
          : <WifiOff size={14} style={{ color: '#f87171' }} />
        }
        <span style={{ fontSize: '8px', color: connected ? '#4ade80' : '#f87171', fontFamily: 'Outfit' }}>
          {connected ? 'ON' : 'OFF'}
        </span>
      </div>
    </aside>
  )
}

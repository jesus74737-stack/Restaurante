import { useState, useEffect } from 'react'
import { Eye, RefreshCw, Clock, ChevronDown, Plus } from 'lucide-react'
import { ordersApi } from '../../utils/api'
import { useSocket } from '../../context/SocketContext'
import toast from 'react-hot-toast'

const STATUSES = [
  { id: 'all', label: 'Todas' },
  { id: 'pending', label: 'Pendientes' },
  { id: 'preparing', label: 'En cocina' },
  { id: 'ready', label: 'Listas' },
  { id: 'delivered', label: 'Entregadas' },
  { id: 'paid', label: 'Pagadas' },
]

const STATUS_FLOW = ['pending', 'preparing', 'ready', 'delivered']

function OrderCard({ order, onUpdate }) {
  const [expanded, setExpanded] = useState(false)
  const [detail, setDetail] = useState(null)
  const [loading, setLoading] = useState(false)

  const badgeClass = `badge-${order.status}`

  const loadDetail = async () => {
    if (detail) return setExpanded(!expanded)
    setLoading(true)
    try {
      const { data } = await ordersApi.getById(order.id)
      setDetail(data)
      setExpanded(true)
    } finally { setLoading(false) }
  }

  const nextStatus = STATUS_FLOW[STATUS_FLOW.indexOf(order.status) + 1]

  const advance = async (e) => {
    e.stopPropagation()
    if (!nextStatus) return
    try {
      await ordersApi.updateStatus(order.id, nextStatus)
      onUpdate(order.id, nextStatus)
      toast.success(`Orden actualizada: ${nextStatus}`)
    } catch { toast.error('Error actualizando orden') }
  }

  const elapsed = Math.floor((Date.now() - new Date(order.created_at)) / 60000)

  return (
    <div className="glass-card rounded-2xl overflow-hidden transition-all animate-slide-up">
      <div className="p-4 cursor-pointer" onClick={loadDetail}>
        <div className="flex items-start justify-between mb-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-display font-bold" style={{ color: '#F5F0E8' }}>
                #{order.order_number}
              </span>
              <span className={`text-xs px-2 py-0.5 rounded-full font-sans ${badgeClass}`}
                style={{ fontFamily: 'Outfit' }}>
                {order.status}
              </span>
            </div>
            {order.table_number && (
              <p style={{ color: '#D4AF37', fontSize: '13px', fontFamily: 'Outfit' }}>
                Mesa {order.table_number} {order.table_location && `· ${order.table_location}`}
              </p>
            )}
            {order.customer_name && (
              <p style={{ color: '#888', fontSize: '12px', fontFamily: 'Outfit' }}>👤 {order.customer_name}</p>
            )}
          </div>
          <div className="text-right">
            <p className="font-display text-lg" style={{ color: '#D4AF37' }}>${parseFloat(order.total).toFixed(2)}</p>
            <div className="flex items-center gap-1 justify-end" style={{ color: elapsed > 30 ? '#f87171' : '#888' }}>
              <Clock size={10} />
              <span style={{ fontSize: '11px', fontFamily: 'Outfit' }}>{elapsed}m</span>
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <button onClick={e => { e.stopPropagation(); loadDetail() }}
            className="flex items-center gap-1 text-sm" style={{ color: '#666', fontFamily: 'Outfit' }}>
            <ChevronDown size={14} style={{ transform: expanded ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />
            {loading ? 'Cargando...' : 'Ver detalle'}
          </button>
          {nextStatus && order.status !== 'paid' && (
            <button onClick={advance} className="btn-gold px-3 py-1 text-sm">
              → {nextStatus === 'preparing' ? 'A cocina' : nextStatus === 'ready' ? 'Listo' : nextStatus === 'delivered' ? 'Entregar' : nextStatus}
            </button>
          )}
        </div>
      </div>

      {expanded && detail && (
        <div className="px-4 pb-4 animate-fade-in" style={{ borderTop: '1px solid #2A2A2A' }}>
          <div className="pt-3 space-y-2">
            {detail.items?.map(item => (
              <div key={item.id} className="flex justify-between text-sm">
                <div>
                  <span style={{ color: '#D4AF37', marginRight: '6px', fontFamily: 'Outfit' }}>×{item.quantity}</span>
                  <span style={{ color: '#F5F0E8', fontFamily: 'Outfit' }}>{item.product_name}</span>
                  {item.modifiers?.length > 0 && (
                    <div style={{ fontSize: '11px', color: '#666', fontFamily: 'Outfit', marginLeft: '18px' }}>
                      {item.modifiers.map(m => m.modifier_name).join(' · ')}
                    </div>
                  )}
                  {item.notes && <div style={{ fontSize: '11px', color: '#D4AF37', marginLeft: '18px' }}>📝 {item.notes}</div>}
                </div>
                <span style={{ color: '#D4AF37', fontFamily: 'Outfit' }}>${parseFloat(item.total_price).toFixed(2)}</span>
              </div>
            ))}
          </div>
          <div className="mt-3 pt-3 space-y-1" style={{ borderTop: '1px solid #1E1E1E' }}>
            {[['Subtotal', detail.subtotal], ['IVA', detail.tax], ['Propina', detail.tip]].map(([l, v]) =>
              parseFloat(v) > 0 ? (
                <div key={l} className="flex justify-between text-xs" style={{ color: '#666', fontFamily: 'Outfit' }}>
                  <span>{l}</span><span>${parseFloat(v).toFixed(2)}</span>
                </div>
              ) : null
            )}
            <div className="flex justify-between font-bold" style={{ color: '#F5F0E8', fontFamily: 'Outfit' }}>
              <span>Total</span><span style={{ color: '#D4AF37' }}>${parseFloat(detail.total).toFixed(2)}</span>
            </div>
          </div>
          {detail.waiter && (
            <p className="mt-2 text-xs" style={{ color: '#555', fontFamily: 'Outfit' }}>Mesero: {detail.waiter}</p>
          )}
          {detail.notes && (
            <p className="mt-1 text-xs" style={{ color: '#D4AF37', fontFamily: 'Outfit' }}>📝 {detail.notes}</p>
          )}
        </div>
      )}
    </div>
  )
}

export default function OrdersPage() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('all')
  const { socket } = useSocket()

  const load = async () => {
    setLoading(true)
    try {
      const params = statusFilter !== 'all' ? { status: statusFilter } : {}
      const { data } = await ordersApi.getAll(params)
      setOrders(data)
    } catch { toast.error('Error cargando órdenes') }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [statusFilter])
  useEffect(() => {
    if (!socket) return
    socket.on('order_created', () => load())
    socket.on('order_updated', (updated) => {
      setOrders(prev => prev.map(o => o.id === updated.id ? { ...o, ...updated } : o))
    })
    socket.on('order_paid', () => load())
    return () => { socket.off('order_created'); socket.off('order_updated'); socket.off('order_paid') }
  }, [socket, statusFilter])

  const handleUpdate = (id, newStatus) => {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, status: newStatus } : o))
  }

  return (
    <div className="min-h-screen p-6 animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-3xl font-bold text-gold-gradient">Órdenes</h1>
          <p style={{ color: '#888', fontSize: '13px', fontFamily: 'Outfit' }}>{orders.length} órdenes</p>
        </div>
        <button onClick={load} className="btn-dark flex items-center gap-2">
          <RefreshCw size={14} /> Actualizar
        </button>
      </div>

      {/* Status filter */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {STATUSES.map(s => (
          <button key={s.id} onClick={() => setStatusFilter(s.id)}
            className="px-4 py-2 rounded-full text-sm flex-shrink-0 transition-all"
            style={{
              background: statusFilter === s.id ? 'linear-gradient(135deg, #A8860A, #D4AF37)' : '#1E1E1E',
              color: statusFilter === s.id ? '#000' : '#888',
              border: statusFilter === s.id ? 'none' : '1px solid #2A2A2A',
              fontFamily: 'Outfit',
            }}>
            {s.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="shimmer-bg rounded-2xl h-40" />)}
        </div>
      ) : orders.length === 0 ? (
        <div className="text-center py-24" style={{ color: '#555' }}>
          <p className="font-display text-xl mb-2">Sin órdenes</p>
          <p style={{ fontFamily: 'Outfit', fontSize: '14px' }}>No hay órdenes con este filtro</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {orders.map(order => (
            <OrderCard key={order.id} order={order} onUpdate={handleUpdate} />
          ))}
        </div>
      )}
    </div>
  )
}

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft, CreditCard, Banknote, Smartphone, Layers, User, StickyNote, Check, Printer } from 'lucide-react'
import { useOrder } from '../../context/OrderContext'
import { ordersApi } from '../../utils/api'
import toast from 'react-hot-toast'

const PAYMENT_METHODS = [
  { id: 'cash', label: 'Efectivo', icon: Banknote },
  { id: 'card', label: 'Tarjeta', icon: CreditCard },
  { id: 'transfer', label: 'Transferencia', icon: Smartphone },
  { id: 'mixed', label: 'Mixto', icon: Layers },
]

export default function CheckoutPage() {
  const { cart, selectedTable, cartSubtotal, cartTax, cartTotal, orderType, dispatch } = useOrder()
  const [paymentMethod, setPaymentMethod] = useState('cash')
  const [amountPaid, setAmountPaid] = useState('')
  const [tip, setTip] = useState(0)
  const [customerName, setCustomerName] = useState('')
  const [waiter, setWaiter] = useState('')
  const [notes, setNotes] = useState('')
  const [step, setStep] = useState('review') // review | pay | success
  const [submitting, setSubmitting] = useState(false)
  const [successData, setSuccessData] = useState(null)
  const navigate = useNavigate()

  const tipAmount = cartTotal * (tip / 100)
  const finalTotal = cartTotal + tipAmount

  const handlePlaceOrder = async () => {
    if (cart.length === 0) return toast.error('El carrito está vacío')
    setSubmitting(true)
    try {
      const { data } = await ordersApi.create({
        table_id: selectedTable?.id,
        type: orderType,
        customer_name: customerName,
        waiter,
        notes,
        items: cart.map(i => ({
          product_id: i.product_id,
          product_name: i.product_name,
          quantity: i.quantity,
          unit_price: i.unit_price,
          modifiers: i.modifiers,
          notes: i.notes,
        }))
      })
      setSuccessData(data)
      setStep('pay')
      toast.success('¡Orden enviada a cocina!')
    } catch (e) {
      toast.error('Error al crear la orden: ' + e.message)
    } finally { setSubmitting(false) }
  }

  const handlePayment = async () => {
    if (!successData) return
    const paid = paymentMethod === 'cash' ? parseFloat(amountPaid) : finalTotal
    if (paymentMethod === 'cash' && paid < finalTotal) {
      return toast.error('El monto pagado es insuficiente')
    }
    setSubmitting(true)
    try {
      const { data } = await ordersApi.pay(successData.id, {
        payment_method: paymentMethod,
        amount_paid: paid,
        tip: tipAmount,
      })
      setSuccessData({ ...successData, ...data })
      setStep('success')
      dispatch({ type: 'CLEAR_CART' })
    } catch (e) {
      toast.error('Error al procesar pago: ' + e.message)
    } finally { setSubmitting(false) }
  }

  // ── Success Screen ─────────────────────────────────────────────────────────
  if (step === 'success') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="w-full max-w-md text-center animate-slide-up">
          <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse-gold"
            style={{ background: 'linear-gradient(135deg, #A8860A, #D4AF37)' }}>
            <Check size={36} color="#000" strokeWidth={3} />
          </div>
          <h2 className="font-display text-3xl font-bold mb-2" style={{ color: '#F5F0E8' }}>¡Pago Exitoso!</h2>
          <p style={{ color: '#888', fontFamily: 'Outfit', marginBottom: '32px' }}>
            Orden #{successData?.order_number} completada
          </p>

          <div className="glass-card rounded-2xl p-6 mb-6 text-left space-y-3">
            {[
              ['Subtotal', `$${cartSubtotal.toFixed(2)}`],
              ['IVA (16%)', `$${cartTax.toFixed(2)}`],
              ['Propina', `$${tipAmount.toFixed(2)}`],
              ['Total', `$${finalTotal.toFixed(2)}`],
              ['Método', PAYMENT_METHODS.find(m => m.id === paymentMethod)?.label],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between" style={{ fontFamily: 'Outfit' }}>
                <span style={{ color: '#888' }}>{k}</span>
                <span style={{ color: k === 'Total' ? '#D4AF37' : '#F5F0E8', fontWeight: k === 'Total' ? 700 : 400 }}>{v}</span>
              </div>
            ))}
            {paymentMethod === 'cash' && parseFloat(amountPaid) > finalTotal && (
              <div className="flex justify-between pt-2" style={{ borderTop: '1px solid #2A2A2A' }}>
                <span style={{ color: '#4ade80', fontFamily: 'Outfit' }}>Cambio</span>
                <span style={{ color: '#4ade80', fontWeight: 700, fontFamily: 'Outfit' }}>
                  ${(parseFloat(amountPaid) - finalTotal).toFixed(2)}
                </span>
              </div>
            )}
          </div>

          <div className="flex gap-3">
            <button className="btn-dark flex-1 flex items-center justify-center gap-2" onClick={() => window.print()}>
              <Printer size={14} /> Imprimir
            </button>
            <button className="btn-gold flex-1" onClick={() => navigate('/tables')}>
              Nueva Mesa
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen p-6 max-w-2xl mx-auto">
      <button onClick={() => navigate('/menu')} className="flex items-center gap-2 mb-6"
        style={{ color: '#888', fontFamily: 'Outfit' }}>
        <ArrowLeft size={16} /> Volver al menú
      </button>

      <h1 className="font-display text-3xl font-bold text-gold-gradient mb-6">
        {step === 'review' ? 'Confirmar Pedido' : 'Procesar Pago'}
      </h1>

      {step === 'review' && (
        <div className="space-y-6 animate-fade-in">
          {/* Order info */}
          <div className="glass-card rounded-2xl p-5 space-y-4">
            <h3 className="font-display text-lg" style={{ color: '#F5F0E8' }}>Información del pedido</h3>
            {selectedTable && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl"
                style={{ background: 'rgba(212,175,55,0.1)', border: '1px solid rgba(212,175,55,0.3)' }}>
                <span style={{ color: '#D4AF37', fontFamily: 'Outfit', fontSize: '14px' }}>
                  📍 Mesa {selectedTable.number} — {selectedTable.location}
                </span>
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs mb-1" style={{ color: '#666', fontFamily: 'Outfit' }}>Cliente</label>
                <input className="pos-input text-sm" placeholder="Nombre del cliente"
                  value={customerName} onChange={e => setCustomerName(e.target.value)} />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: '#666', fontFamily: 'Outfit' }}>Mesero</label>
                <input className="pos-input text-sm" placeholder="Tu nombre"
                  value={waiter} onChange={e => setWaiter(e.target.value)} />
              </div>
            </div>
            <div>
              <label className="block text-xs mb-1" style={{ color: '#666', fontFamily: 'Outfit' }}>Notas</label>
              <textarea className="pos-input resize-none text-sm" rows={2}
                placeholder="Notas generales del pedido..." value={notes} onChange={e => setNotes(e.target.value)} />
            </div>
          </div>

          {/* Items */}
          <div className="glass-card rounded-2xl p-5">
            <h3 className="font-display text-lg mb-4" style={{ color: '#F5F0E8' }}>Resumen ({cart.length} productos)</h3>
            <div className="space-y-3">
              {cart.map(item => {
                const modPrice = item.modifiers?.reduce((s, m) => s + parseFloat(m.price || 0), 0) || 0
                return (
                  <div key={item.cartId} className="flex items-start justify-between pb-3"
                    style={{ borderBottom: '1px solid #1E1E1E' }}>
                    <div className="flex-1">
                      <p style={{ color: '#F5F0E8', fontSize: '14px', fontFamily: 'Outfit' }}>
                        <span style={{ color: '#D4AF37', marginRight: '8px' }}>×{item.quantity}</span>
                        {item.product_name}
                      </p>
                      {item.modifiers?.length > 0 && (
                        <p style={{ fontSize: '11px', color: '#666', fontFamily: 'Outfit', marginTop: '2px' }}>
                          {item.modifiers.map(m => m.name).join(' · ')}
                        </p>
                      )}
                      {item.notes && <p style={{ fontSize: '11px', color: '#D4AF37', fontFamily: 'Outfit' }}>📝 {item.notes}</p>}
                    </div>
                    <span className="font-display" style={{ color: '#D4AF37', fontSize: '14px', marginLeft: '12px' }}>
                      ${((item.unit_price + modPrice) * item.quantity).toFixed(2)}
                    </span>
                  </div>
                )
              })}
            </div>
            <div className="mt-4 space-y-2">
              {[['Subtotal', cartSubtotal], ['IVA (16%)', cartTax]].map(([l, v]) => (
                <div key={l} className="flex justify-between text-sm" style={{ color: '#888', fontFamily: 'Outfit' }}>
                  <span>{l}</span><span>${v.toFixed(2)}</span>
                </div>
              ))}
              <div className="flex justify-between font-display text-xl pt-2"
                style={{ borderTop: '1px solid #2A2A2A', color: '#F5F0E8' }}>
                <span>Total</span>
                <span style={{ color: '#D4AF37' }}>${cartTotal.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <button onClick={handlePlaceOrder} disabled={submitting} className="btn-gold w-full py-4 text-lg">
            {submitting ? 'Enviando a cocina...' : '🍳 Enviar a Cocina'}
          </button>
        </div>
      )}

      {step === 'pay' && (
        <div className="space-y-6 animate-fade-in">
          <div className="glass-card rounded-2xl p-5 flex items-center justify-between">
            <div>
              <p style={{ color: '#888', fontSize: '13px', fontFamily: 'Outfit' }}>Orden en cocina</p>
              <p className="font-display text-lg" style={{ color: '#4ade80' }}>#{successData?.order_number}</p>
            </div>
            <div className="text-right">
              <p style={{ color: '#888', fontSize: '13px', fontFamily: 'Outfit' }}>Total a pagar</p>
              <p className="font-display text-2xl" style={{ color: '#D4AF37' }}>${finalTotal.toFixed(2)}</p>
            </div>
          </div>

          {/* Payment method */}
          <div className="glass-card rounded-2xl p-5">
            <h3 className="font-display text-lg mb-4" style={{ color: '#F5F0E8' }}>Método de Pago</h3>
            <div className="grid grid-cols-2 gap-3">
              {PAYMENT_METHODS.map(({ id, label, icon: Icon }) => (
                <button key={id} onClick={() => setPaymentMethod(id)}
                  className="flex items-center gap-3 p-4 rounded-xl transition-all"
                  style={{
                    background: paymentMethod === id ? 'rgba(212,175,55,0.1)' : '#1E1E1E',
                    border: paymentMethod === id ? '2px solid #D4AF37' : '2px solid #2A2A2A',
                  }}>
                  <Icon size={18} style={{ color: paymentMethod === id ? '#D4AF37' : '#666' }} />
                  <span style={{ color: paymentMethod === id ? '#F5F0E8' : '#666', fontFamily: 'Outfit', fontSize: '14px' }}>
                    {label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Tip */}
          <div className="glass-card rounded-2xl p-5">
            <h3 className="font-display text-lg mb-4" style={{ color: '#F5F0E8' }}>Propina</h3>
            <div className="flex gap-3">
              {[0, 10, 15, 20].map(t => (
                <button key={t} onClick={() => setTip(t)}
                  className="flex-1 py-3 rounded-xl text-sm transition-all"
                  style={{
                    background: tip === t ? 'linear-gradient(135deg, #A8860A, #D4AF37)' : '#1E1E1E',
                    color: tip === t ? '#000' : '#666',
                    border: tip === t ? 'none' : '1px solid #2A2A2A',
                    fontFamily: 'Outfit', fontWeight: tip === t ? 700 : 400,
                  }}>
                  {t === 0 ? 'Sin propina' : `${t}%`}
                </button>
              ))}
            </div>
            {tip > 0 && (
              <p className="text-sm mt-2 text-right" style={{ color: '#D4AF37', fontFamily: 'Outfit' }}>
                Propina: ${tipAmount.toFixed(2)}
              </p>
            )}
          </div>

          {/* Cash amount */}
          {paymentMethod === 'cash' && (
            <div className="glass-card rounded-2xl p-5">
              <h3 className="font-display text-lg mb-3" style={{ color: '#F5F0E8' }}>Monto Recibido</h3>
              <input type="number" className="pos-input text-xl font-display text-center" step="0.01"
                placeholder={`${finalTotal.toFixed(2)}`}
                value={amountPaid} onChange={e => setAmountPaid(e.target.value)} />
              {amountPaid && parseFloat(amountPaid) >= finalTotal && (
                <p className="text-center mt-2" style={{ color: '#4ade80', fontFamily: 'Outfit' }}>
                  Cambio: ${(parseFloat(amountPaid) - finalTotal).toFixed(2)}
                </p>
              )}
              <div className="grid grid-cols-4 gap-2 mt-3">
                {[20, 50, 100, 200].map(bill => (
                  <button key={bill} onClick={() => setAmountPaid(String(Math.ceil(finalTotal / bill) * bill))}
                    className="btn-dark py-2 text-sm">${bill}</button>
                ))}
              </div>
            </div>
          )}

          <div className="flex gap-3">
            <button onClick={() => navigate('/orders')} className="btn-dark flex-1 py-3">
              Ver Órdenes
            </button>
            <button onClick={handlePayment} disabled={submitting} className="btn-gold flex-1 py-3 text-lg">
              {submitting ? 'Procesando...' : `Cobrar $${finalTotal.toFixed(2)}`}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

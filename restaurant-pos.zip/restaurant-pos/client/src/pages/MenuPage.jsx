import { useState, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { Search, ShoppingCart, Plus, Minus, X, ChevronRight, ArrowLeft, Clock, Check } from 'lucide-react'
import { categoriesApi, productsApi } from '../../utils/api'
import { useOrder } from '../../context/OrderContext'
import toast from 'react-hot-toast'

// ── Item Detail Modal ──────────────────────────────────────────────────────────
function ItemModal({ product, onClose, onAdd }) {
  const [qty, setQty] = useState(1)
  const [notes, setNotes] = useState('')
  const [selected, setSelected] = useState({}) // groupId -> [modifiers]
  const [loading, setLoading] = useState(true)
  const [detail, setDetail] = useState(null)

  useEffect(() => {
    productsApi.getById(product.id).then(({ data }) => {
      setDetail(data)
      // Pre-set required groups
      data.modifier_groups?.forEach(g => {
        if (g.required && g.modifiers?.length) {
          setSelected(prev => ({ ...prev, [g.id]: [g.modifiers[0]] }))
        }
      })
      setLoading(false)
    })
  }, [product.id])

  const toggleMod = (group, mod) => {
    setSelected(prev => {
      const curr = prev[group.id] || []
      if (group.max_select === 1) {
        return { ...prev, [group.id]: [mod] }
      }
      const idx = curr.findIndex(m => m.id === mod.id)
      if (idx >= 0) return { ...prev, [group.id]: curr.filter(m => m.id !== mod.id) }
      if (curr.length >= group.max_select) return prev
      return { ...prev, [group.id]: [...curr, mod] }
    })
  }

  const allMods = Object.values(selected).flat()
  const modTotal = allMods.reduce((s, m) => s + parseFloat(m.price || 0), 0)
  const total = (parseFloat(product.price) + modTotal) * qty

  const isValid = () => {
    if (!detail) return false
    return detail.modifier_groups?.every(g => !g.required || (selected[g.id]?.length > 0)) ?? true
  }

  const handleAdd = () => {
    if (!isValid()) return toast.error('Por favor selecciona las opciones requeridas')
    onAdd({
      product_id: product.id,
      product_name: product.name,
      unit_price: parseFloat(product.price),
      quantity: qty,
      modifiers: allMods.map(m => ({ modifier_id: m.id, name: m.name, price: m.price || 0 })),
      notes,
    })
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center p-0 md:p-4"
      style={{ background: 'rgba(0,0,0,0.85)' }} onClick={onClose}>
      <div className="w-full md:max-w-lg rounded-t-3xl md:rounded-2xl overflow-hidden animate-slide-up"
        style={{ background: '#141414', border: '1px solid #2A2A2A', maxHeight: '90vh', overflowY: 'auto' }}
        onClick={e => e.stopPropagation()}>

        {/* Header */}
        <div className="relative p-6 pb-4" style={{ borderBottom: '1px solid #2A2A2A' }}>
          <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center"
            style={{ background: '#2A2A2A' }}>
            <X size={14} style={{ color: '#888' }} />
          </button>
          <h2 className="font-display text-2xl font-bold" style={{ color: '#F5F0E8', paddingRight: '2rem' }}>
            {product.name}
          </h2>
          <p style={{ color: '#888', fontSize: '13px', marginTop: '4px', fontFamily: 'Outfit' }}>
            {product.description}
          </p>
          <div className="flex items-center gap-4 mt-3">
            <span className="font-display text-xl" style={{ color: '#D4AF37' }}>
              ${parseFloat(product.price).toFixed(2)}
            </span>
            {product.preparation_time && (
              <div className="flex items-center gap-1" style={{ color: '#666' }}>
                <Clock size={12} />
                <span style={{ fontSize: '12px', fontFamily: 'Outfit' }}>{product.preparation_time} min</span>
              </div>
            )}
          </div>
        </div>

        {/* Modifier Groups */}
        <div className="p-6 space-y-6">
          {loading && (
            <div className="space-y-4">
              {[1, 2].map(i => <div key={i} className="shimmer-bg h-20 rounded-xl" />)}
            </div>
          )}
          {detail?.modifier_groups?.map(group => (
            <div key={group.id}>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="font-sans font-semibold" style={{ color: '#F5F0E8', fontFamily: 'Outfit' }}>
                    {group.name}
                    {group.required && (
                      <span className="ml-2 text-xs px-2 py-0.5 rounded-full"
                        style={{ background: 'rgba(212,175,55,0.2)', color: '#D4AF37', fontSize: '10px' }}>
                        Requerido
                      </span>
                    )}
                  </h3>
                  <p style={{ fontSize: '11px', color: '#666', fontFamily: 'Outfit' }}>
                    {group.max_select === 1 ? 'Elige 1 opción' : `Elige hasta ${group.max_select}`}
                  </p>
                </div>
              </div>
              <div className="space-y-2">
                {group.modifiers?.map(mod => {
                  const isSelected = (selected[group.id] || []).some(m => m.id === mod.id)
                  return (
                    <button key={mod.id} onClick={() => toggleMod(group, mod)}
                      className="w-full flex items-center justify-between p-3 rounded-xl transition-all"
                      style={{
                        background: isSelected ? 'rgba(212,175,55,0.1)' : '#1E1E1E',
                        border: isSelected ? '1px solid rgba(212,175,55,0.5)' : '1px solid #2A2A2A',
                      }}>
                      <div className="flex items-center gap-3">
                        <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all"
                          style={{
                            borderColor: isSelected ? '#D4AF37' : '#444',
                            background: isSelected ? '#D4AF37' : 'transparent',
                          }}>
                          {isSelected && <Check size={10} color="#000" strokeWidth={3} />}
                        </div>
                        <span style={{ color: '#F5F0E8', fontSize: '14px', fontFamily: 'Outfit' }}>{mod.name}</span>
                      </div>
                      {parseFloat(mod.price) !== 0 && (
                        <span style={{
                          color: parseFloat(mod.price) > 0 ? '#D4AF37' : '#4ade80',
                          fontSize: '13px', fontFamily: 'Outfit', fontWeight: 500,
                        }}>
                          {parseFloat(mod.price) > 0 ? '+' : ''}${parseFloat(mod.price).toFixed(2)}
                        </span>
                      )}
                    </button>
                  )
                })}
              </div>
            </div>
          ))}

          {/* Notes */}
          <div>
            <label className="block text-sm mb-2" style={{ color: '#888', fontFamily: 'Outfit' }}>
              Notas especiales (opcional)
            </label>
            <textarea className="pos-input resize-none" rows={2}
              placeholder="Sin cebolla, poco picante, alergia..."
              value={notes} onChange={e => setNotes(e.target.value)} />
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 pt-0 space-y-4" style={{ borderTop: '1px solid #2A2A2A' }}>
          {/* Quantity */}
          <div className="flex items-center justify-between">
            <span style={{ color: '#C8C0A8', fontFamily: 'Outfit' }}>Cantidad</span>
            <div className="flex items-center gap-3">
              <button onClick={() => setQty(q => Math.max(1, q - 1))}
                className="w-8 h-8 rounded-full flex items-center justify-center"
                style={{ background: '#2A2A2A' }}>
                <Minus size={14} style={{ color: '#888' }} />
              </button>
              <span className="font-display text-xl w-8 text-center" style={{ color: '#F5F0E8' }}>{qty}</span>
              <button onClick={() => setQty(q => q + 1)}
                className="w-8 h-8 rounded-full flex items-center justify-center"
                style={{ background: '#D4AF37' }}>
                <Plus size={14} color="#000" />
              </button>
            </div>
          </div>

          {/* Add button */}
          <button onClick={handleAdd} className="btn-gold w-full py-3 flex items-center justify-between"
            style={{ opacity: isValid() ? 1 : 0.5 }}>
            <span>Agregar al pedido</span>
            <span className="font-display text-lg">${total.toFixed(2)}</span>
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Cart Sidebar ───────────────────────────────────────────────────────────────
function CartSidebar({ isOpen, onClose }) {
  const { cart, dispatch, cartSubtotal, cartTax, cartTotal, selectedTable, orderType,
    customerName, waiter, notes } = useOrder()
  const navigate = useNavigate()

  if (!isOpen) return null

  const handleCheckout = () => {
    if (cart.length === 0) return toast.error('El carrito está vacío')
    onClose()
    navigate('/checkout')
  }

  return (
    <div className="fixed inset-0 z-40 flex justify-end">
      <div className="absolute inset-0" style={{ background: 'rgba(0,0,0,0.6)' }} onClick={onClose} />
      <div className="relative w-full max-w-sm h-full flex flex-col animate-slide-right"
        style={{ background: '#141414', borderLeft: '1px solid #2A2A2A' }}>

        <div className="p-5 flex items-center justify-between" style={{ borderBottom: '1px solid #2A2A2A' }}>
          <div>
            <h2 className="font-display text-xl font-bold" style={{ color: '#F5F0E8' }}>Pedido Actual</h2>
            {selectedTable && (
              <p style={{ color: '#D4AF37', fontSize: '13px', fontFamily: 'Outfit' }}>
                Mesa {selectedTable.number} — {selectedTable.location}
              </p>
            )}
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center"
            style={{ background: '#2A2A2A' }}>
            <X size={14} style={{ color: '#888' }} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <div className="text-center py-16" style={{ color: '#555' }}>
              <ShoppingCart size={40} className="mx-auto mb-3 opacity-30" />
              <p style={{ fontFamily: 'Outfit' }}>El carrito está vacío</p>
            </div>
          ) : cart.map(item => {
            const modPrice = item.modifiers?.reduce((s, m) => s + parseFloat(m.price || 0), 0) || 0
            const itemTotal = (item.unit_price + modPrice) * item.quantity
            return (
              <div key={item.cartId} className="glass-card rounded-xl p-3">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex-1">
                    <p className="font-sans text-sm font-medium" style={{ color: '#F5F0E8', fontFamily: 'Outfit' }}>
                      {item.product_name}
                    </p>
                    {item.modifiers?.length > 0 && (
                      <p style={{ fontSize: '11px', color: '#666', fontFamily: 'Outfit' }}>
                        {item.modifiers.map(m => m.name).join(', ')}
                      </p>
                    )}
                    {item.notes && (
                      <p style={{ fontSize: '11px', color: '#D4AF37', fontFamily: 'Outfit' }}>📝 {item.notes}</p>
                    )}
                  </div>
                  <button onClick={() => dispatch({ type: 'REMOVE_ITEM', payload: item.cartId })}
                    style={{ color: '#555', padding: '2px', marginLeft: '8px' }}>
                    <X size={12} />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button onClick={() => dispatch({ type: 'UPDATE_QTY', payload: { cartId: item.cartId, qty: item.quantity - 1 } })}
                      className="w-6 h-6 rounded-full flex items-center justify-center"
                      style={{ background: '#2A2A2A' }}>
                      <Minus size={10} style={{ color: '#888' }} />
                    </button>
                    <span style={{ color: '#F5F0E8', fontSize: '14px', minWidth: '20px', textAlign: 'center' }}>
                      {item.quantity}
                    </span>
                    <button onClick={() => dispatch({ type: 'UPDATE_QTY', payload: { cartId: item.cartId, qty: item.quantity + 1 } })}
                      className="w-6 h-6 rounded-full flex items-center justify-center"
                      style={{ background: '#2A2A2A' }}>
                      <Plus size={10} style={{ color: '#888' }} />
                    </button>
                  </div>
                  <span className="font-display" style={{ color: '#D4AF37', fontSize: '14px' }}>
                    ${itemTotal.toFixed(2)}
                  </span>
                </div>
              </div>
            )
          })}
        </div>

        {cart.length > 0 && (
          <div className="p-5 space-y-3" style={{ borderTop: '1px solid #2A2A2A' }}>
            <div className="space-y-1">
              {[['Subtotal', cartSubtotal], ['IVA (16%)', cartTax]].map(([label, val]) => (
                <div key={label} className="flex justify-between text-sm" style={{ color: '#888', fontFamily: 'Outfit' }}>
                  <span>{label}</span><span>${val.toFixed(2)}</span>
                </div>
              ))}
              <div className="flex justify-between font-display text-lg pt-2"
                style={{ borderTop: '1px solid #2A2A2A', color: '#F5F0E8' }}>
                <span>Total</span>
                <span style={{ color: '#D4AF37' }}>${cartTotal.toFixed(2)}</span>
              </div>
            </div>
            <button onClick={handleCheckout} className="btn-gold w-full py-3 flex items-center justify-between">
              <span>Confirmar Pedido</span>
              <ChevronRight size={16} />
            </button>
            <button onClick={() => dispatch({ type: 'CLEAR_CART' })}
              className="w-full text-center text-sm" style={{ color: '#555', fontFamily: 'Outfit' }}>
              Limpiar carrito
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

// ── Main Menu Page ─────────────────────────────────────────────────────────────
export default function MenuPage() {
  const [categories, setCategories] = useState([])
  const [products, setProducts] = useState([])
  const [activeCategory, setActiveCategory] = useState(null)
  const [search, setSearch] = useState('')
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [cartOpen, setCartOpen] = useState(false)
  const { dispatch, cartCount, selectedTable } = useOrder()
  const navigate = useNavigate()

  useEffect(() => {
    categoriesApi.getAll().then(({ data }) => {
      setCategories(data)
      if (data.length) setActiveCategory(data[0].id)
    })
  }, [])

  useEffect(() => {
    if (!activeCategory) return
    productsApi.getAll({ category_id: activeCategory }).then(({ data }) => setProducts(data))
  }, [activeCategory])

  const filtered = search
    ? products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()))
    : products

  const addToCart = (item) => {
    dispatch({ type: 'ADD_ITEM', payload: item })
    toast.success(`${item.product_name} agregado`, {
      style: { background: '#1E1E1E', color: '#F5F0E8', border: '1px solid #D4AF37' }
    })
  }

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      {/* Top bar */}
      <div className="flex items-center justify-between p-4 md:px-6 flex-shrink-0"
        style={{ borderBottom: '1px solid #2A2A2A', background: '#0A0A0A' }}>
        <div>
          <h1 className="font-display text-2xl font-bold text-gold-gradient">Menú</h1>
          {selectedTable ? (
            <p style={{ color: '#D4AF37', fontSize: '13px', fontFamily: 'Outfit' }}>
              Mesa {selectedTable.number} · {selectedTable.location}
            </p>
          ) : (
            <button onClick={() => navigate('/tables')} style={{ color: '#666', fontSize: '12px', fontFamily: 'Outfit' }}>
              ← Selecciona una mesa
            </button>
          )}
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#555' }} />
            <input className="pos-input pl-8" style={{ width: '200px', fontSize: '13px' }}
              placeholder="Buscar platillo..."
              value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <button onClick={() => setCartOpen(true)} className="relative btn-gold flex items-center gap-2">
            <ShoppingCart size={16} />
            <span>Pedido</span>
            {cartCount > 0 && (
              <span className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold"
                style={{ background: '#000', color: '#D4AF37' }}>{cartCount}</span>
            )}
          </button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Category sidebar */}
        <div className="w-20 md:w-28 flex-shrink-0 overflow-y-auto py-4 space-y-2 px-2"
          style={{ background: '#0D0D0D', borderRight: '1px solid #1A1A1A' }}>
          {categories.map(cat => (
            <button key={cat.id} onClick={() => { setActiveCategory(cat.id); setSearch('') }}
              className="w-full flex flex-col items-center gap-1 py-3 px-2 rounded-xl transition-all"
              style={{
                background: activeCategory === cat.id ? 'rgba(212,175,55,0.1)' : 'transparent',
                border: activeCategory === cat.id ? '1px solid rgba(212,175,55,0.4)' : '1px solid transparent',
              }}>
              <span style={{ fontSize: '22px' }}>{cat.icon}</span>
              <span style={{
                fontSize: '10px', color: activeCategory === cat.id ? '#D4AF37' : '#555',
                fontFamily: 'Outfit', textAlign: 'center', lineHeight: 1.2,
              }}>{cat.name}</span>
            </button>
          ))}
        </div>

        {/* Products grid */}
        <div className="flex-1 overflow-y-auto p-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
            {filtered.map(product => (
              <button key={product.id} onClick={() => setSelectedProduct(product)}
                className="glass-card rounded-2xl p-4 text-left transition-all duration-200 hover:-translate-y-1 hover:gold-glow animate-slide-up">
                <div className="text-3xl mb-3 text-center">
                  {categories.find(c => c.id === product.category_id)?.icon || '🍽️'}
                </div>
                <p className="font-sans text-sm font-medium mb-1 line-clamp-2"
                  style={{ color: '#F5F0E8', fontFamily: 'Outfit', lineHeight: 1.3 }}>
                  {product.name}
                </p>
                <p className="text-xs mb-3 line-clamp-2" style={{ color: '#666', fontFamily: 'Outfit' }}>
                  {product.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="font-display font-bold" style={{ color: '#D4AF37' }}>
                    ${parseFloat(product.price).toFixed(2)}
                  </span>
                  <div className="w-7 h-7 rounded-full flex items-center justify-center"
                    style={{ background: '#D4AF37' }}>
                    <Plus size={14} color="#000" />
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {selectedProduct && (
        <ItemModal product={selectedProduct} onClose={() => setSelectedProduct(null)} onAdd={addToCart} />
      )}
      <CartSidebar isOpen={cartOpen} onClose={() => setCartOpen(false)} />
    </div>
  )
}

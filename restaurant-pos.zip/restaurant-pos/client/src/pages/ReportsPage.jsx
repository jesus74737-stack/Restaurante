import { useState, useEffect } from 'react'
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import { TrendingUp, ShoppingBag, DollarSign, CreditCard, Banknote, Calendar } from 'lucide-react'
import { reportsApi } from '../../utils/api'
import toast from 'react-hot-toast'

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div className="glass-card rounded-xl p-3" style={{ border: '1px solid rgba(212,175,55,0.3)' }}>
      <p style={{ color: '#D4AF37', fontFamily: 'Outfit', fontSize: '12px', marginBottom: '4px' }}>{label}</p>
      {payload.map(p => (
        <p key={p.name} style={{ color: '#F5F0E8', fontFamily: 'Outfit', fontSize: '13px' }}>
          {p.name}: <span style={{ color: '#D4AF37' }}>${parseFloat(p.value).toFixed(2)}</span>
        </p>
      ))}
    </div>
  )
}

function StatCard({ icon: Icon, label, value, sub, color = '#D4AF37' }) {
  return (
    <div className="glass-card rounded-2xl p-5">
      <div className="flex items-start justify-between mb-3">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ background: `${color}20`, border: `1px solid ${color}40` }}>
          <Icon size={18} style={{ color }} />
        </div>
      </div>
      <p className="font-display text-2xl font-bold mb-1" style={{ color: '#F5F0E8' }}>{value}</p>
      <p style={{ fontSize: '12px', color: '#888', fontFamily: 'Outfit' }}>{label}</p>
      {sub && <p style={{ fontSize: '11px', color, fontFamily: 'Outfit', marginTop: '2px' }}>{sub}</p>}
    </div>
  )
}

export default function ReportsPage() {
  const [daily, setDaily] = useState(null)
  const [weekly, setWeekly] = useState([])
  const [date, setDate] = useState(new Date().toISOString().split('T')[0])
  const [loading, setLoading] = useState(true)

  const load = async () => {
    setLoading(true)
    try {
      const [d, w] = await Promise.all([reportsApi.daily(date), reportsApi.weekly()])
      setDaily(d.data)
      setWeekly(w.data)
    } catch { toast.error('Error cargando reportes') }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [date])

  const s = daily?.summary

  return (
    <div className="min-h-screen p-6 animate-fade-in">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-gold-gradient">Reportes</h1>
          <p style={{ color: '#888', fontSize: '13px', fontFamily: 'Outfit' }}>Análisis de ventas</p>
        </div>
        <div className="flex items-center gap-2">
          <Calendar size={16} style={{ color: '#D4AF37' }} />
          <input type="date" className="pos-input" style={{ width: 'auto' }}
            value={date} onChange={e => setDate(e.target.value)} />
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {Array.from({ length: 4 }).map((_, i) => <div key={i} className="shimmer-bg rounded-2xl h-28" />)}
        </div>
      ) : s && (
        <>
          {/* Stats cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <StatCard icon={ShoppingBag} label="Órdenes completadas" value={s.total_orders} color="#60a5fa" />
            <StatCard icon={DollarSign} label="Ingresos totales"
              value={`$${parseFloat(s.total_revenue).toFixed(2)}`}
              sub={`IVA: $${parseFloat(s.total_tax).toFixed(2)}`} />
            <StatCard icon={Banknote} label="Efectivo"
              value={`$${parseFloat(s.cash).toFixed(2)}`} color="#4ade80" />
            <StatCard icon={CreditCard} label="Tarjeta"
              value={`$${parseFloat(s.card).toFixed(2)}`} color="#a78bfa" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Hourly chart */}
            {daily.by_hour?.length > 0 && (
              <div className="glass-card rounded-2xl p-5">
                <h3 className="font-display text-lg mb-4" style={{ color: '#F5F0E8' }}>Ventas por hora</h3>
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={daily.by_hour.map(h => ({ hora: `${h.hour}h`, ventas: parseFloat(h.revenue), pedidos: h.orders }))}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#2A2A2A" />
                    <XAxis dataKey="hora" tick={{ fill: '#666', fontSize: 11, fontFamily: 'Outfit' }} />
                    <YAxis tick={{ fill: '#666', fontSize: 11 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="ventas" fill="#D4AF37" radius={[4, 4, 0, 0]} name="Ventas ($)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* Top products */}
            {daily.top_products?.length > 0 && (
              <div className="glass-card rounded-2xl p-5">
                <h3 className="font-display text-lg mb-4" style={{ color: '#F5F0E8' }}>Top Productos</h3>
                <div className="space-y-3">
                  {daily.top_products.slice(0, 6).map((p, i) => (
                    <div key={p.product_name} className="flex items-center gap-3">
                      <span className="font-display text-sm w-5 text-right" style={{ color: i < 3 ? '#D4AF37' : '#555' }}>
                        {i + 1}
                      </span>
                      <div className="flex-1">
                        <div className="flex justify-between mb-1">
                          <span style={{ fontSize: '13px', color: '#F5F0E8', fontFamily: 'Outfit' }}>
                            {p.product_name}
                          </span>
                          <span style={{ fontSize: '13px', color: '#D4AF37', fontFamily: 'Outfit' }}>
                            {p.qty}× · ${parseFloat(p.revenue).toFixed(2)}
                          </span>
                        </div>
                        <div className="h-1 rounded-full" style={{ background: '#2A2A2A' }}>
                          <div className="h-1 rounded-full" style={{
                            background: i < 3 ? 'linear-gradient(to right, #A8860A, #D4AF37)' : '#444',
                            width: `${(p.qty / daily.top_products[0].qty) * 100}%`,
                            transition: 'width 1s ease',
                          }} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Weekly trend */}
          {weekly.length > 0 && (
            <div className="glass-card rounded-2xl p-5">
              <h3 className="font-display text-lg mb-4" style={{ color: '#F5F0E8' }}>Tendencia Semanal</h3>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={weekly.map(d => ({
                  fecha: new Date(d.date).toLocaleDateString('es', { weekday: 'short', day: 'numeric' }),
                  ingresos: parseFloat(d.revenue),
                  pedidos: d.orders
                }))}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2A2A2A" />
                  <XAxis dataKey="fecha" tick={{ fill: '#666', fontSize: 11 }} />
                  <YAxis tick={{ fill: '#666', fontSize: 11 }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line type="monotone" dataKey="ingresos" stroke="#D4AF37" strokeWidth={2} dot={{ fill: '#D4AF37', r: 4 }} name="Ingresos ($)" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </>
      )}
    </div>
  )
}

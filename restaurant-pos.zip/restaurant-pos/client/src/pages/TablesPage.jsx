import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Users, RefreshCw, MapPin } from 'lucide-react'
import { tablesApi } from '../../utils/api'
import { useOrder } from '../../context/OrderContext'
import { useSocket } from '../../context/SocketContext'
import toast from 'react-hot-toast'

const STATUS_CONFIG = {
  available: { label: 'Disponible', color: '#4ade80', bg: 'rgba(34,197,94,0.08)', border: 'rgba(34,197,94,0.4)' },
  occupied: { label: 'Ocupada', color: '#D4AF37', bg: 'rgba(212,175,55,0.08)', border: 'rgba(212,175,55,0.6)' },
  reserved: { label: 'Reservada', color: '#60a5fa', bg: 'rgba(59,130,246,0.08)', border: 'rgba(59,130,246,0.4)' },
  cleaning: { label: 'Limpieza', color: '#f87171', bg: 'rgba(239,68,68,0.08)', border: 'rgba(239,68,68,0.4)' },
}

const LOCATIONS = ['Todos', 'Salón', 'Terraza', 'Barra', 'VIP']

export default function TablesPage() {
  const [tables, setTables] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('Todos')
  const { dispatch } = useOrder()
  const { socket } = useSocket()
  const navigate = useNavigate()

  const load = async () => {
    try {
      const { data } = await tablesApi.getAll()
      setTables(data)
    } catch { toast.error('Error cargando mesas') }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])
  useEffect(() => {
    if (!socket) return
    socket.on('table_updated', (t) => setTables(prev => prev.map(x => x.id === t.id ? { ...x, ...t } : x)))
    socket.on('order_paid', () => load())
    return () => { socket.off('table_updated'); socket.off('order_paid') }
  }, [socket])

  const handleTableClick = (table) => {
    if (table.status === 'cleaning') return toast.error('Mesa en limpieza')
    if (table.status === 'reserved') {
      toast('Mesa reservada — confirma con el cliente', { icon: '📋' })
    }
    dispatch({ type: 'SET_TABLE', payload: table })
    navigate('/menu')
  }

  const filtered = filter === 'Todos' ? tables : tables.filter(t => t.location === filter)
  const stats = {
    total: tables.length,
    available: tables.filter(t => t.status === 'available').length,
    occupied: tables.filter(t => t.status === 'occupied').length,
  }

  return (
    <div className="min-h-screen p-6 animate-fade-in">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h1 className="font-display text-3xl font-bold text-gold-gradient">Mapa de Mesas</h1>
            <p style={{ color: '#C8C0A8', fontSize: '14px', fontFamily: 'Outfit' }}>
              Selecciona una mesa para tomar la orden
            </p>
          </div>
          <button onClick={load} className="btn-dark flex items-center gap-2">
            <RefreshCw size={14} /> Actualizar
          </button>
        </div>

        {/* Stats */}
        <div className="flex gap-4 mt-4">
          {[
            { label: 'Total', value: stats.total, color: '#C8C0A8' },
            { label: 'Disponibles', value: stats.available, color: '#4ade80' },
            { label: 'Ocupadas', value: stats.occupied, color: '#D4AF37' },
          ].map(s => (
            <div key={s.label} className="glass-card rounded-xl px-4 py-3">
              <div className="text-2xl font-bold font-display" style={{ color: s.color }}>{s.value}</div>
              <div style={{ fontSize: '12px', color: '#888', fontFamily: 'Outfit' }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Location filter */}
      <div className="flex gap-2 mb-6 flex-wrap">
        {LOCATIONS.map(loc => (
          <button key={loc} onClick={() => setFilter(loc)}
            className="px-4 py-2 rounded-full text-sm font-sans transition-all"
            style={{
              background: filter === loc ? 'linear-gradient(135deg, #A8860A, #D4AF37)' : '#1E1E1E',
              color: filter === loc ? '#000' : '#888',
              border: filter === loc ? 'none' : '1px solid #2A2A2A',
              fontFamily: 'Outfit',
            }}>
            {loc}
          </button>
        ))}
      </div>

      {/* Legend */}
      <div className="flex gap-4 mb-6 flex-wrap">
        {Object.entries(STATUS_CONFIG).map(([key, cfg]) => (
          <div key={key} className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full" style={{ background: cfg.color }} />
            <span style={{ fontSize: '12px', color: '#888', fontFamily: 'Outfit' }}>{cfg.label}</span>
          </div>
        ))}
      </div>

      {/* Tables Grid */}
      {loading ? (
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-4">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="shimmer-bg rounded-2xl h-32" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 gap-4">
          {filtered.map(table => {
            const cfg = STATUS_CONFIG[table.status] || STATUS_CONFIG.available
            return (
              <button key={table.id} onClick={() => handleTableClick(table)}
                className="relative rounded-2xl p-4 flex flex-col items-center justify-center gap-2 transition-all duration-200 hover:-translate-y-1 animate-slide-up"
                style={{
                  background: cfg.bg,
                  border: `2px solid ${cfg.border}`,
                  minHeight: '120px',
                  cursor: table.status === 'cleaning' ? 'not-allowed' : 'pointer',
                }}>
                {table.status === 'occupied' && (
                  <div className="absolute top-2 right-2 w-2 h-2 rounded-full animate-pulse"
                    style={{ background: '#D4AF37' }} />
                )}
                <span className="font-display text-xl font-bold" style={{ color: cfg.color }}>
                  {table.number}
                </span>
                <div className="flex items-center gap-1" style={{ color: '#888' }}>
                  <Users size={12} />
                  <span style={{ fontSize: '11px', fontFamily: 'Outfit' }}>{table.capacity}</span>
                </div>
                <div className="flex items-center gap-1" style={{ color: '#666' }}>
                  <MapPin size={10} />
                  <span style={{ fontSize: '10px', fontFamily: 'Outfit' }}>{table.location}</span>
                </div>
                <span className="text-xs px-2 py-0.5 rounded-full"
                  style={{ background: cfg.border, color: cfg.color, fontSize: '9px', fontFamily: 'Outfit' }}>
                  {cfg.label}
                </span>
                {parseInt(table.active_orders) > 0 && (
                  <span className="absolute -top-1 -left-1 w-5 h-5 rounded-full text-xs flex items-center justify-center font-bold"
                    style={{ background: '#D4AF37', color: '#000', fontSize: '10px' }}>
                    {table.active_orders}
                  </span>
                )}
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}

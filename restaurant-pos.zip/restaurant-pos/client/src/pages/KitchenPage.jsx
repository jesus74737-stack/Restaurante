import { useState, useEffect } from 'react'
import { ChefHat, Clock, Check, RefreshCw, Bell } from 'lucide-react'
import { ordersApi } from '../../utils/api'
import { useSocket } from '../../context/SocketContext'
import toast from 'react-hot-toast'

const PRIORITY_COLOR = (mins) => {
  if (mins > 30) return '#f87171'
  if (mins > 20) return '#fb923c'
  if (mins > 10) return '#facc15'
  return '#4ade80'
}

function KitchenCard({ order, onAdvance }) {
  const elapsed = Math.floor((Date.now() - new Date(order.created_at)) / 60000)
  const urgentColor = PRIORITY_COLOR(elapsed)

  const advance = async () => {
    const next = order.status === 'pending' ? 'preparing' : order.status === 'preparing' ? 'ready' : null
    if (!next) return
    try {
      await ordersApi.updateStatus(order.id, next)
      onAdvance(order.id, next)
    } catch { toast.error('Error') }
  }

  const statusLabel = { pending: '⏳ En espera', preparing: '🔥 Preparando', ready: '✅ Listo' }

  return (
    <div className="rounded-2xl overflow-hidden animate-slide-up"
      style={{
        background: '#141414',
        border: `2px solid ${order.status === 'ready' ? '#4ade80' : order.status === 'preparing' ? '#D4AF37' : '#2A2A2A'}`,
        boxShadow: order.status === 'preparing' ? '0 0 20px rgba(212,175,55,0.15)' : 'none',
      }}>

      {/* Card header */}
      <div className="p-4 flex items-center justify-between"
        style={{
          background: order.status === 'preparing' ? 'rgba(212,175,55,0.05)' :
            order.status === 'ready' ? 'rgba(34,197,94,0.05)' : '#1A1A1A',
        }}>
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="font-display text-lg font-bold" style={{ color: '#F5F0E8' }}>
              #{order.order_number?.split('-').pop()}
            </span>
            {order.table_number && (
              <span className="text-sm px-2 py-0.5 rounded-full"
                style={{ background: 'rgba(212,175,55,0.15)', color: '#D4AF37', fontFamily: 'Outfit' }}>
                Mesa {order.table_number}
              </span>
            )}
          </div>
          <span style={{ fontSize: '12px', color: '#888', fontFamily: 'Outfit' }}>
            {statusLabel[order.status]}
          </span>
        </div>
        <div className="text-right">
          <div className="flex items-center gap-1 justify-end"
            style={{ color: urgentColor }}>
            <Clock size={14} />
            <span className="font-display text-lg font-bold">{elapsed}m</span>
          </div>
          {elapsed > 20 && (
            <span className="animate-pulse" style={{ fontSize: '10px', color: '#f87171', fontFamily: 'Outfit' }}>
              ¡URGENTE!
            </span>
          )}
        </div>
      </div>

      {/* Items */}
      <div className="p-4 space-y-3">
        {order.items?.map(item => (
          <div key={item.id} className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 font-bold"
              style={{ background: 'rgba(212,175,55,0.2)', color: '#D4AF37', fontFamily: 'Outfit', fontSize: '14px' }}>
              {item.quantity}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold" style={{ color: '#F5F0E8', fontFamily: 'Outfit', fontSize: '14px' }}>
                {item.product_name}
              </p>
              {item.modifiers?.length > 0 && (
                <div className="mt-1 space-y-0.5">
                  {item.modifiers.map(m => (
                    <p key={m.id} style={{ fontSize: '11px', color: '#666', fontFamily: 'Outfit' }}>
                      • {m.modifier_name}
                    </p>
                  ))}
                </div>
              )}
              {item.notes && (
                <p className="mt-1 px-2 py-1 rounded-lg" style={{
                  background: 'rgba(239,68,68,0.1)', color: '#f87171', fontSize: '11px', fontFamily: 'Outfit'
                }}>
                  ⚠️ {item.notes}
                </p>
              )}
            </div>
          </div>
        ))}

        {order.notes && (
          <div className="p-2 rounded-xl mt-2" style={{ background: 'rgba(212,175,55,0.08)', border: '1px solid rgba(212,175,55,0.2)' }}>
            <p style={{ fontSize: '12px', color: '#D4AF37', fontFamily: 'Outfit' }}>📝 {order.notes}</p>
          </div>
        )}
      </div>

      {/* Action */}
      {order.status !== 'ready' && (
        <div className="p-4 pt-0">
          <button onClick={advance} className="btn-gold w-full py-2.5 flex items-center justify-center gap-2">
            {order.status === 'pending' ? (
              <><ChefHat size={16} /> Comenzar a preparar</>
            ) : (
              <><Check size={16} /> Marcar como listo</>
            )}
          </button>
        </div>
      )}
    </div>
  )
}

export default function KitchenPage() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const { socket } = useSocket()

  const load = async () => {
    try {
      const pending = await ordersApi.getAll({ status: 'pending' })
      const preparing = await ordersApi.getAll({ status: 'preparing' })
      const ready = await ordersApi.getAll({ status: 'ready' })
      const all = [...pending.data, ...preparing.data, ...ready.data]
      // Load details for each
      const detailed = await Promise.all(all.map(o => ordersApi.getById(o.id).then(r => r.data)))
      setOrders(detailed)
    } catch { toast.error('Error cargando cocina') }
    finally { setLoading(false) }
  }

  useEffect(() => {
    load()
    socket?.emit('join_kitchen')
    const interval = setInterval(load, 30000) // refresh every 30s
    return () => clearInterval(interval)
  }, [socket])

  useEffect(() => {
    if (!socket) return
    socket.on('new_order', () => { load(); toast('🔔 Nueva orden!', { icon: '🍽️' }) })
    socket.on('order_status_changed', () => load())
    socket.on('item_added', () => load())
    return () => { socket.off('new_order'); socket.off('order_status_changed'); socket.off('item_added') }
  }, [socket])

  const handleAdvance = (id, newStatus) => {
    setOrders(prev => prev.map(o => o.id === id ? { ...o, status: newStatus } : o))
    if (newStatus === 'ready') toast.success('¡Orden lista para servir!', {
      style: { background: '#1E1E1E', color: '#4ade80', border: '1px solid #4ade80' }
    })
  }

  const pending = orders.filter(o => o.status === 'pending')
  const preparing = orders.filter(o => o.status === 'preparing')
  const ready = orders.filter(o => o.status === 'ready')

  return (
    <div className="min-h-screen p-6 animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: 'rgba(212,175,55,0.15)', border: '1px solid rgba(212,175,55,0.3)' }}>
            <ChefHat size={20} style={{ color: '#D4AF37' }} />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-gold-gradient">Pantalla de Cocina</h1>
            <p style={{ color: '#888', fontSize: '12px', fontFamily: 'Outfit' }}>
              {orders.length} órdenes activas · Actualización automática
            </p>
          </div>
        </div>
        <button onClick={load} className="btn-dark flex items-center gap-2">
          <RefreshCw size={14} /> Actualizar
        </button>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[
          { label: 'En espera', count: pending.length, color: '#888' },
          { label: 'Preparando', count: preparing.length, color: '#D4AF37' },
          { label: 'Listos', count: ready.length, color: '#4ade80' },
        ].map(s => (
          <div key={s.label} className="glass-card rounded-xl p-4 text-center">
            <p className="font-display text-3xl font-bold" style={{ color: s.color }}>{s.count}</p>
            <p style={{ fontSize: '12px', color: '#666', fontFamily: 'Outfit' }}>{s.label}</p>
          </div>
        ))}
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="shimmer-bg rounded-2xl h-48" />)}
        </div>
      ) : orders.length === 0 ? (
        <div className="text-center py-24" style={{ color: '#555' }}>
          <ChefHat size={60} className="mx-auto mb-4 opacity-20" />
          <p className="font-display text-2xl mb-2">Cocina despejada</p>
          <p style={{ fontFamily: 'Outfit' }}>No hay órdenes pendientes</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {/* Show in priority order: ready > preparing > pending */}
          {[...ready, ...preparing, ...pending].map(order => (
            <KitchenCard key={order.id} order={order} onAdvance={handleAdvance} />
          ))}
        </div>
      )}
    </div>
  )
}

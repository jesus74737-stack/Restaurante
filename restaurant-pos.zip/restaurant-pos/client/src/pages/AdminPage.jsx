import { useState, useEffect } from 'react'
import { Plus, Edit3, ToggleLeft, ToggleRight, Save, X, Utensils, Tag, Package } from 'lucide-react'
import { categoriesApi, productsApi } from '../../utils/api'
import toast from 'react-hot-toast'

function ProductForm({ product, categories, onSave, onCancel }) {
  const [form, setForm] = useState(product || { name: '', description: '', price: '', category_id: '', preparation_time: 15 })
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const handleSubmit = async () => {
    if (!form.name || !form.price || !form.category_id) return toast.error('Completa los campos obligatorios')
    try {
      if (product?.id) {
        await productsApi.update(product.id, form)
        toast.success('Producto actualizado')
      } else {
        await productsApi.create(form)
        toast.success('Producto creado')
      }
      onSave()
    } catch { toast.error('Error guardando producto') }
  }

  return (
    <div className="glass-card rounded-2xl p-6 animate-fade-in">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-display text-lg" style={{ color: '#F5F0E8' }}>
          {product ? 'Editar Producto' : 'Nuevo Producto'}
        </h3>
        <button onClick={onCancel}><X size={16} style={{ color: '#666' }} /></button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs mb-1" style={{ color: '#666', fontFamily: 'Outfit' }}>Nombre *</label>
          <input className="pos-input" value={form.name} onChange={e => set('name', e.target.value)} />
        </div>
        <div>
          <label className="block text-xs mb-1" style={{ color: '#666', fontFamily: 'Outfit' }}>Categoría *</label>
          <select className="pos-input" value={form.category_id} onChange={e => set('category_id', e.target.value)}
            style={{ background: '#1E1E1E', color: '#F5F0E8' }}>
            <option value="">Selecciona...</option>
            {categories.map(c => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-xs mb-1" style={{ color: '#666', fontFamily: 'Outfit' }}>Precio *</label>
          <input type="number" step="0.01" className="pos-input" value={form.price} onChange={e => set('price', e.target.value)} />
        </div>
        <div>
          <label className="block text-xs mb-1" style={{ color: '#666', fontFamily: 'Outfit' }}>Tiempo prep. (min)</label>
          <input type="number" className="pos-input" value={form.preparation_time} onChange={e => set('preparation_time', e.target.value)} />
        </div>
        <div className="md:col-span-2">
          <label className="block text-xs mb-1" style={{ color: '#666', fontFamily: 'Outfit' }}>Descripción</label>
          <textarea className="pos-input resize-none" rows={2} value={form.description} onChange={e => set('description', e.target.value)} />
        </div>
      </div>
      <div className="flex gap-3 mt-4">
        <button onClick={onCancel} className="btn-dark flex-1">Cancelar</button>
        <button onClick={handleSubmit} className="btn-gold flex-1 flex items-center justify-center gap-2">
          <Save size={14} /> Guardar
        </button>
      </div>
    </div>
  )
}

export default function AdminPage() {
  const [categories, setCategories] = useState([])
  const [products, setProducts] = useState([])
  const [activeTab, setActiveTab] = useState('products')
  const [editingProduct, setEditingProduct] = useState(null)
  const [showForm, setShowForm] = useState(false)
  const [catFilter, setCatFilter] = useState(null)

  const load = async () => {
    const [cats, prods] = await Promise.all([categoriesApi.getAll(), productsApi.getAll({})])
    setCategories(cats.data)
    setProducts(prods.data)
  }

  useEffect(() => { load() }, [])

  const toggleAvailable = async (product) => {
    try {
      await productsApi.update(product.id, { ...product, available: !product.available })
      setProducts(prev => prev.map(p => p.id === product.id ? { ...p, available: !p.available } : p))
      toast.success(product.available ? 'Producto desactivado' : 'Producto activado')
    } catch { toast.error('Error') }
  }

  const filtered = catFilter ? products.filter(p => p.category_id === catFilter) : products

  return (
    <div className="min-h-screen p-6 animate-fade-in">
      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold text-gold-gradient">Administración</h1>
        <p style={{ color: '#888', fontSize: '13px', fontFamily: 'Outfit' }}>Gestión del menú y configuración</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-3 mb-6">
        {[
          { id: 'products', label: 'Productos', icon: Package },
          { id: 'categories', label: 'Categorías', icon: Tag },
        ].map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => setActiveTab(id)}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl transition-all"
            style={{
              background: activeTab === id ? 'linear-gradient(135deg, #A8860A, #D4AF37)' : '#1E1E1E',
              color: activeTab === id ? '#000' : '#888',
              border: activeTab === id ? 'none' : '1px solid #2A2A2A',
              fontFamily: 'Outfit',
            }}>
            <Icon size={14} /> {label}
          </button>
        ))}
      </div>

      {activeTab === 'products' && (
        <div>
          <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
            <div className="flex gap-2 overflow-x-auto">
              <button onClick={() => setCatFilter(null)}
                className="px-3 py-1.5 rounded-full text-xs flex-shrink-0 transition-all"
                style={{
                  background: !catFilter ? 'rgba(212,175,55,0.2)' : '#1E1E1E',
                  color: !catFilter ? '#D4AF37' : '#666',
                  border: !catFilter ? '1px solid rgba(212,175,55,0.5)' : '1px solid #2A2A2A',
                  fontFamily: 'Outfit',
                }}>Todos</button>
              {categories.map(c => (
                <button key={c.id} onClick={() => setCatFilter(c.id)}
                  className="px-3 py-1.5 rounded-full text-xs flex-shrink-0 transition-all"
                  style={{
                    background: catFilter === c.id ? 'rgba(212,175,55,0.2)' : '#1E1E1E',
                    color: catFilter === c.id ? '#D4AF37' : '#666',
                    border: catFilter === c.id ? '1px solid rgba(212,175,55,0.5)' : '1px solid #2A2A2A',
                    fontFamily: 'Outfit',
                  }}>{c.icon} {c.name}</button>
              ))}
            </div>
            <button onClick={() => { setEditingProduct(null); setShowForm(true) }}
              className="btn-gold flex items-center gap-2 flex-shrink-0">
              <Plus size={14} /> Agregar Producto
            </button>
          </div>

          {showForm && (
            <div className="mb-4">
              <ProductForm product={editingProduct} categories={categories}
                onSave={() => { setShowForm(false); setEditingProduct(null); load() }}
                onCancel={() => { setShowForm(false); setEditingProduct(null) }} />
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {filtered.map(product => (
              <div key={product.id} className="glass-card rounded-xl p-4 flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <p className="font-sans text-sm font-medium truncate"
                      style={{ color: product.available ? '#F5F0E8' : '#555', fontFamily: 'Outfit' }}>
                      {product.name}
                    </p>
                    {!product.available && (
                      <span style={{ fontSize: '10px', color: '#f87171', background: 'rgba(239,68,68,0.1)',
                        padding: '1px 6px', borderRadius: '4px', fontFamily: 'Outfit', flexShrink: 0 }}>
                        Inactivo
                      </span>
                    )}
                  </div>
                  <p style={{ fontSize: '12px', color: '#888', fontFamily: 'Outfit' }}>
                    {product.category_name}
                  </p>
                  <p className="font-display" style={{ color: '#D4AF37', fontSize: '15px' }}>
                    ${parseFloat(product.price).toFixed(2)}
                  </p>
                </div>
                <div className="flex flex-col gap-2">
                  <button onClick={() => { setEditingProduct(product); setShowForm(true) }}
                    className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{ background: '#2A2A2A' }}>
                    <Edit3 size={12} style={{ color: '#888' }} />
                  </button>
                  <button onClick={() => toggleAvailable(product)}
                    className="w-8 h-8 rounded-lg flex items-center justify-center transition-all"
                    style={{ background: product.available ? 'rgba(212,175,55,0.15)' : '#2A2A2A' }}>
                    {product.available
                      ? <ToggleRight size={14} style={{ color: '#D4AF37' }} />
                      : <ToggleLeft size={14} style={{ color: '#555' }} />
                    }
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'categories' && (
        <div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {categories.map(cat => (
              <div key={cat.id} className="glass-card rounded-2xl p-5 text-center animate-slide-up">
                <div className="text-4xl mb-2">{cat.icon}</div>
                <p className="font-display font-medium" style={{ color: '#F5F0E8' }}>{cat.name}</p>
                <p style={{ fontSize: '11px', color: '#666', fontFamily: 'Outfit', marginTop: '4px' }}>
                  {products.filter(p => p.category_id === cat.id).length} productos
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

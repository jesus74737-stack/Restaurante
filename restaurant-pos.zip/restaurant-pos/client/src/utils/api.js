import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 10000,
})

export const categoriesApi = {
  getAll: () => api.get('/categories'),
  create: (data) => api.post('/categories', data),
  update: (id, data) => api.put(`/categories/${id}`, data),
}

export const productsApi = {
  getAll: (params) => api.get('/products', { params }),
  getById: (id) => api.get(`/products/${id}`),
  create: (data) => api.post('/products', data),
  update: (id, data) => api.put(`/products/${id}`, data),
}

export const tablesApi = {
  getAll: () => api.get('/tables'),
  updateStatus: (id, status) => api.put(`/tables/${id}/status`, { status }),
}

export const ordersApi = {
  getAll: (params) => api.get('/orders', { params }),
  getById: (id) => api.get(`/orders/${id}`),
  create: (data) => api.post('/orders', data),
  updateStatus: (id, status) => api.put(`/orders/${id}/status`, { status }),
  pay: (id, data) => api.post(`/orders/${id}/pay`, data),
  addItem: (id, item) => api.post(`/orders/${id}/items`, item),
  updateItemStatus: (itemId, status) => api.put(`/orders/items/${itemId}/status`, { status }),
}

export const reportsApi = {
  daily: (date) => api.get('/reports/daily', { params: { date } }),
  weekly: () => api.get('/reports/weekly'),
}

export default api

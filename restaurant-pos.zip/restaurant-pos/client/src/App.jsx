import { Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { SocketProvider } from './context/SocketContext'
import { OrderProvider } from './context/OrderContext'
import Sidebar from './components/Layout/Sidebar'
import TablesPage from './pages/TablesPage'
import MenuPage from './pages/MenuPage'
import CheckoutPage from './pages/CheckoutPage'
import OrdersPage from './pages/OrdersPage'
import KitchenPage from './pages/KitchenPage'
import ReportsPage from './pages/ReportsPage'
import AdminPage from './pages/AdminPage'

export default function App() {
  return (
    <SocketProvider>
      <OrderProvider>
        <div className="flex min-h-screen" style={{ background: '#0A0A0A' }}>
          <Sidebar />
          <main className="flex-1 ml-16 md:ml-20 overflow-auto">
            <Routes>
              <Route path="/" element={<Navigate to="/tables" replace />} />
              <Route path="/tables" element={<TablesPage />} />
              <Route path="/menu" element={<MenuPage />} />
              <Route path="/checkout" element={<CheckoutPage />} />
              <Route path="/orders" element={<OrdersPage />} />
              <Route path="/kitchen" element={<KitchenPage />} />
              <Route path="/reports" element={<ReportsPage />} />
              <Route path="/admin" element={<AdminPage />} />
            </Routes>
          </main>
        </div>
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#1E1E1E',
              color: '#F5F0E8',
              border: '1px solid #2A2A2A',
              fontFamily: 'Outfit',
              fontSize: '14px',
            },
            success: { iconTheme: { primary: '#D4AF37', secondary: '#000' } },
          }}
        />
      </OrderProvider>
    </SocketProvider>
  )
}

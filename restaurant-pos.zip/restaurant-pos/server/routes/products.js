const router = require('express').Router();
const pool = require('../config/database');

router.get('/', async (req, res) => {
  try {
    const { category_id } = req.query;
    let q = `SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id=c.id WHERE p.available=true`;
    const params = [];
    if (category_id) { params.push(category_id); q += ` AND p.category_id=$${params.length}`; }
    q += ' ORDER BY p.name';
    res.json((await pool.query(q, params)).rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/:id', async (req, res) => {
  try {
    const prod = await pool.query('SELECT * FROM products WHERE id=$1', [req.params.id]);
    if (!prod.rows[0]) return res.status(404).json({ error: 'Not found' });

    const groups = await pool.query('SELECT * FROM modifier_groups WHERE product_id=$1 ORDER BY sort_order', [req.params.id]);
    for (const g of groups.rows) {
      const mods = await pool.query('SELECT * FROM modifiers WHERE group_id=$1 AND available=true ORDER BY sort_order', [g.id]);
      g.modifiers = mods.rows;
    }
    res.json({ ...prod.rows[0], modifier_groups: groups.rows });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/', async (req, res) => {
  const { category_id, name, description, price, preparation_time } = req.body;
  try {
    const r = await pool.query(
      'INSERT INTO products (category_id,name,description,price,preparation_time) VALUES($1,$2,$3,$4,$5) RETURNING *',
      [category_id, name, description, price, preparation_time || 15]
    );
    res.json(r.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.put('/:id', async (req, res) => {
  const { name, description, price, available, preparation_time } = req.body;
  try {
    const r = await pool.query(
      'UPDATE products SET name=$1,description=$2,price=$3,available=$4,preparation_time=$5 WHERE id=$6 RETURNING *',
      [name, description, price, available, preparation_time, req.params.id]
    );
    res.json(r.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;

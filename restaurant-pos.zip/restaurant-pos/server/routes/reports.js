const router = require('express').Router();
const pool = require('../config/database');

router.get('/daily', async (req, res) => {
  const { date } = req.query;
  const d = date || new Date().toISOString().split('T')[0];
  try {
    const summary = await pool.query(`
      SELECT 
        COUNT(*) as total_orders,
        COALESCE(SUM(total),0) as total_revenue,
        COALESCE(SUM(tax),0) as total_tax,
        COALESCE(SUM(tip),0) as total_tips,
        COALESCE(SUM(CASE WHEN payment_method='cash' THEN total ELSE 0 END),0) as cash,
        COALESCE(SUM(CASE WHEN payment_method='card' THEN total ELSE 0 END),0) as card,
        COALESCE(SUM(CASE WHEN payment_method='mixed' THEN total ELSE 0 END),0) as mixed
      FROM orders WHERE DATE(created_at)=$1 AND status='paid'
    `, [d]);

    const topProducts = await pool.query(`
      SELECT oi.product_name, SUM(oi.quantity) as qty, SUM(oi.total_price) as revenue
      FROM order_items oi JOIN orders o ON oi.order_id=o.id
      WHERE DATE(o.created_at)=$1 AND o.status='paid'
      GROUP BY oi.product_name ORDER BY qty DESC LIMIT 10
    `, [d]);

    const byHour = await pool.query(`
      SELECT EXTRACT(HOUR FROM created_at) as hour, COUNT(*) as orders, COALESCE(SUM(total),0) as revenue
      FROM orders WHERE DATE(created_at)=$1 AND status='paid'
      GROUP BY hour ORDER BY hour
    `, [d]);

    res.json({ date: d, summary: summary.rows[0], top_products: topProducts.rows, by_hour: byHour.rows });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/weekly', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT DATE(created_at) as date,
        COUNT(*) as orders,
        COALESCE(SUM(total),0) as revenue
      FROM orders WHERE created_at >= NOW() - INTERVAL '7 days' AND status='paid'
      GROUP BY DATE(created_at) ORDER BY date
    `);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;

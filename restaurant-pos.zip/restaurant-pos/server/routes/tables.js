const router = require('express').Router();
const pool = require('../config/database');

router.get('/', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT t.*, 
        (SELECT COUNT(*) FROM orders o WHERE o.table_id=t.id AND o.status NOT IN ('paid','cancelled')) as active_orders
      FROM tables t ORDER BY t.location, t.number
    `);
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.put('/:id/status', async (req, res) => {
  const { status } = req.body;
  try {
    const r = await pool.query('UPDATE tables SET status=$1 WHERE id=$2 RETURNING *', [status, req.params.id]);
    req.app.get('io').emit('table_updated', r.rows[0]);
    res.json(r.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;

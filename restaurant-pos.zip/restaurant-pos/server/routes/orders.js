const router = require('express').Router();
const pool = require('../config/database');

// Generate order number
function generateOrderNumber() {
  const now = new Date();
  return `ORD-${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}-${String(Math.floor(Math.random()*9999)).padStart(4,'0')}`;
}

// GET all active orders
router.get('/', async (req, res) => {
  try {
    const { status, table_id } = req.query;
    let q = `SELECT o.*, t.number as table_number, t.location as table_location FROM orders o LEFT JOIN tables t ON o.table_id=t.id WHERE 1=1`;
    const params = [];
    if (status) { params.push(status); q += ` AND o.status=$${params.length}`; }
    if (table_id) { params.push(table_id); q += ` AND o.table_id=$${params.length}`; }
    q += ' ORDER BY o.created_at DESC LIMIT 100';
    res.json((await pool.query(q, params)).rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET single order with items
router.get('/:id', async (req, res) => {
  try {
    const order = await pool.query(`
      SELECT o.*, t.number as table_number FROM orders o LEFT JOIN tables t ON o.table_id=t.id WHERE o.id=$1
    `, [req.params.id]);
    if (!order.rows[0]) return res.status(404).json({ error: 'Not found' });

    const items = await pool.query('SELECT * FROM order_items WHERE order_id=$1 ORDER BY created_at', [req.params.id]);
    for (const item of items.rows) {
      const mods = await pool.query('SELECT * FROM order_item_modifiers WHERE order_item_id=$1', [item.id]);
      item.modifiers = mods.rows;
    }
    res.json({ ...order.rows[0], items: items.rows });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// CREATE order
router.post('/', async (req, res) => {
  const { table_id, items, type = 'dine_in', customer_name, waiter, notes } = req.body;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    let subtotal = 0;
    const orderNumber = generateOrderNumber();

    const orderRes = await client.query(`
      INSERT INTO orders (table_id, order_number, status, type, customer_name, waiter, notes, subtotal, tax, total)
      VALUES ($1,$2,'pending',$3,$4,$5,$6,0,0,0) RETURNING *
    `, [table_id, orderNumber, type, customer_name, waiter, notes]);
    const order = orderRes.rows[0];

    for (const item of items) {
      let itemTotal = item.unit_price * item.quantity;
      let modTotal = 0;
      if (item.modifiers) {
        for (const m of item.modifiers) modTotal += parseFloat(m.price || 0);
      }
      itemTotal += modTotal * item.quantity;
      subtotal += itemTotal;

      const itemRes = await client.query(`
        INSERT INTO order_items (order_id, product_id, product_name, quantity, unit_price, total_price, notes)
        VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *
      `, [order.id, item.product_id, item.product_name, item.quantity, item.unit_price + modTotal, itemTotal, item.notes]);

      if (item.modifiers?.length) {
        for (const m of item.modifiers) {
          await client.query(`
            INSERT INTO order_item_modifiers (order_item_id, modifier_id, modifier_name, price)
            VALUES ($1,$2,$3,$4)
          `, [itemRes.rows[0].id, m.modifier_id, m.name, m.price || 0]);
        }
      }
    }

    const tax = subtotal * 0.16;
    const total = subtotal + tax;
    await client.query('UPDATE orders SET subtotal=$1, tax=$2, total=$3 WHERE id=$4', [subtotal, tax, total, order.id]);

    if (table_id) {
      await client.query("UPDATE tables SET status='occupied' WHERE id=$1", [table_id]);
    }

    await client.query('COMMIT');
    const finalOrder = { ...order, subtotal, tax, total };
    req.app.get('io').to('kitchen').emit('new_order', finalOrder);
    req.app.get('io').emit('order_created', finalOrder);
    res.json(finalOrder);
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally { client.release(); }
});

// UPDATE order status
router.put('/:id/status', async (req, res) => {
  const { status } = req.body;
  try {
    const r = await pool.query(
      'UPDATE orders SET status=$1, updated_at=NOW() WHERE id=$2 RETURNING *',
      [status, req.params.id]
    );
    const order = r.rows[0];
    if (status === 'paid' || status === 'cancelled') {
      await pool.query("UPDATE tables SET status='available' WHERE id=$1", [order.table_id]);
    }
    req.app.get('io').emit('order_updated', order);
    req.app.get('io').to('kitchen').emit('order_status_changed', order);
    res.json(order);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PROCESS payment
router.post('/:id/pay', async (req, res) => {
  const { payment_method, amount_paid, tip = 0 } = req.body;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const order = await client.query('SELECT * FROM orders WHERE id=$1', [req.params.id]);
    if (!order.rows[0]) return res.status(404).json({ error: 'Order not found' });

    const o = order.rows[0];
    const finalTotal = parseFloat(o.total) + parseFloat(tip);

    await client.query(`
      UPDATE orders SET payment_method=$1, payment_status='paid', status='paid', tip=$2, total=$3, updated_at=NOW() WHERE id=$4
    `, [payment_method, tip, finalTotal, req.params.id]);

    await client.query(`
      INSERT INTO payments (order_id, method, amount, reference) VALUES ($1,$2,$3,$4)
    `, [req.params.id, payment_method, amount_paid, `PAY-${Date.now()}`]);

    await client.query("UPDATE tables SET status='available' WHERE id=$1", [o.table_id]);

    await client.query('COMMIT');
    req.app.get('io').emit('order_paid', { id: req.params.id, table_id: o.table_id });
    res.json({ success: true, order_number: o.order_number, total: finalTotal, change: amount_paid - finalTotal });
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally { client.release(); }
});

// Add item to existing order
router.post('/:id/items', async (req, res) => {
  const { product_id, product_name, quantity, unit_price, modifiers, notes } = req.body;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    let modTotal = 0;
    if (modifiers) for (const m of modifiers) modTotal += parseFloat(m.price || 0);
    const totalPrice = (unit_price + modTotal) * quantity;

    const itemRes = await client.query(`
      INSERT INTO order_items (order_id, product_id, product_name, quantity, unit_price, total_price, notes)
      VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *
    `, [req.params.id, product_id, product_name, quantity, unit_price + modTotal, totalPrice, notes]);

    if (modifiers?.length) {
      for (const m of modifiers) {
        await client.query(`INSERT INTO order_item_modifiers (order_item_id, modifier_id, modifier_name, price) VALUES ($1,$2,$3,$4)`,
          [itemRes.rows[0].id, m.modifier_id, m.name, m.price || 0]);
      }
    }

    // Recalculate total
    const totals = await client.query('SELECT SUM(total_price) as sub FROM order_items WHERE order_id=$1', [req.params.id]);
    const sub = parseFloat(totals.rows[0].sub);
    const tax = sub * 0.16;
    await client.query('UPDATE orders SET subtotal=$1,tax=$2,total=$3,updated_at=NOW() WHERE id=$4', [sub, tax, sub+tax, req.params.id]);

    await client.query('COMMIT');
    req.app.get('io').to('kitchen').emit('item_added', { order_id: req.params.id, item: itemRes.rows[0] });
    res.json(itemRes.rows[0]);
  } catch (e) {
    await client.query('ROLLBACK');
    res.status(500).json({ error: e.message });
  } finally { client.release(); }
});

// Update item status (kitchen)
router.put('/items/:itemId/status', async (req, res) => {
  const { status } = req.body;
  try {
    const r = await pool.query('UPDATE order_items SET status=$1 WHERE id=$2 RETURNING *', [status, req.params.itemId]);
    req.app.get('io').emit('item_status_changed', r.rows[0]);
    res.json(r.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;

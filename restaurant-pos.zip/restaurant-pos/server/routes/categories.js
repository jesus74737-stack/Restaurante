const router = require('express').Router();
const pool = require('../config/database');

router.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM categories WHERE active=true ORDER BY sort_order');
    res.json(result.rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/', async (req, res) => {
  const { name, icon, sort_order } = req.body;
  try {
    const r = await pool.query('INSERT INTO categories (name,icon,sort_order) VALUES($1,$2,$3) RETURNING *', [name, icon, sort_order || 0]);
    res.json(r.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.put('/:id', async (req, res) => {
  const { name, icon, active } = req.body;
  try {
    const r = await pool.query('UPDATE categories SET name=$1,icon=$2,active=$3 WHERE id=$4 RETURNING *', [name, icon, active, req.params.id]);
    res.json(r.rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;

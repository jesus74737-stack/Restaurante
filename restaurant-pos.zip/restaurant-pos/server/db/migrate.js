const pool = require('../config/database');

async function migrate() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Categories
    await client.query(`
      CREATE TABLE IF NOT EXISTS categories (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        icon VARCHAR(50),
        color VARCHAR(20) DEFAULT '#D4AF37',
        sort_order INT DEFAULT 0,
        active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);

    // Products
    await client.query(`
      CREATE TABLE IF NOT EXISTS products (
        id SERIAL PRIMARY KEY,
        category_id INT REFERENCES categories(id),
        name VARCHAR(200) NOT NULL,
        description TEXT,
        price DECIMAL(10,2) NOT NULL,
        image_url TEXT,
        available BOOLEAN DEFAULT true,
        preparation_time INT DEFAULT 15,
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);

    // Modifier Groups (e.g., "Toppings", "Extras", "Sauces")
    await client.query(`
      CREATE TABLE IF NOT EXISTS modifier_groups (
        id SERIAL PRIMARY KEY,
        product_id INT REFERENCES products(id) ON DELETE CASCADE,
        name VARCHAR(100) NOT NULL,
        required BOOLEAN DEFAULT false,
        min_select INT DEFAULT 0,
        max_select INT DEFAULT 1,
        sort_order INT DEFAULT 0
      )
    `);

    // Modifiers (individual options within groups)
    await client.query(`
      CREATE TABLE IF NOT EXISTS modifiers (
        id SERIAL PRIMARY KEY,
        group_id INT REFERENCES modifier_groups(id) ON DELETE CASCADE,
        name VARCHAR(100) NOT NULL,
        price DECIMAL(10,2) DEFAULT 0,
        available BOOLEAN DEFAULT true,
        sort_order INT DEFAULT 0
      )
    `);

    // Tables
    await client.query(`
      CREATE TABLE IF NOT EXISTS tables (
        id SERIAL PRIMARY KEY,
        number VARCHAR(10) NOT NULL UNIQUE,
        capacity INT DEFAULT 4,
        status VARCHAR(20) DEFAULT 'available',
        location VARCHAR(50) DEFAULT 'salon',
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);

    // Orders
    await client.query(`
      CREATE TABLE IF NOT EXISTS orders (
        id SERIAL PRIMARY KEY,
        table_id INT REFERENCES tables(id),
        order_number VARCHAR(20) UNIQUE NOT NULL,
        status VARCHAR(30) DEFAULT 'pending',
        type VARCHAR(20) DEFAULT 'dine_in',
        subtotal DECIMAL(10,2) DEFAULT 0,
        tax DECIMAL(10,2) DEFAULT 0,
        discount DECIMAL(10,2) DEFAULT 0,
        tip DECIMAL(10,2) DEFAULT 0,
        total DECIMAL(10,2) DEFAULT 0,
        payment_method VARCHAR(30),
        payment_status VARCHAR(20) DEFAULT 'pending',
        customer_name VARCHAR(100),
        notes TEXT,
        waiter VARCHAR(100),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      )
    `);

    // Order Items
    await client.query(`
      CREATE TABLE IF NOT EXISTS order_items (
        id SERIAL PRIMARY KEY,
        order_id INT REFERENCES orders(id) ON DELETE CASCADE,
        product_id INT REFERENCES products(id),
        product_name VARCHAR(200) NOT NULL,
        quantity INT DEFAULT 1,
        unit_price DECIMAL(10,2) NOT NULL,
        total_price DECIMAL(10,2) NOT NULL,
        notes TEXT,
        status VARCHAR(20) DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);

    // Order Item Modifiers
    await client.query(`
      CREATE TABLE IF NOT EXISTS order_item_modifiers (
        id SERIAL PRIMARY KEY,
        order_item_id INT REFERENCES order_items(id) ON DELETE CASCADE,
        modifier_id INT REFERENCES modifiers(id),
        modifier_name VARCHAR(100) NOT NULL,
        price DECIMAL(10,2) DEFAULT 0
      )
    `);

    // Payments
    await client.query(`
      CREATE TABLE IF NOT EXISTS payments (
        id SERIAL PRIMARY KEY,
        order_id INT REFERENCES orders(id),
        method VARCHAR(30) NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        reference VARCHAR(100),
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);

    // Daily Reports Cache
    await client.query(`
      CREATE TABLE IF NOT EXISTS daily_reports (
        id SERIAL PRIMARY KEY,
        date DATE UNIQUE NOT NULL,
        total_orders INT DEFAULT 0,
        total_revenue DECIMAL(10,2) DEFAULT 0,
        total_tax DECIMAL(10,2) DEFAULT 0,
        cash_revenue DECIMAL(10,2) DEFAULT 0,
        card_revenue DECIMAL(10,2) DEFAULT 0,
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);

    await client.query('COMMIT');
    console.log('✅ Database migrated successfully');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('❌ Migration failed:', err);
    throw err;
  } finally {
    client.release();
    await pool.end();
  }
}

migrate().catch(console.error);

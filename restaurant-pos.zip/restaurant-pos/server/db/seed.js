const pool = require('../config/database');

async function seed() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Categories
    const cats = await client.query(`
      INSERT INTO categories (name, icon, sort_order) VALUES
        ('Entradas', '🥗', 1),
        ('Hamburguesas', '🍔', 2),
        ('Pizzas', '🍕', 3),
        ('Pastas', '🍝', 4),
        ('Carnes', '🥩', 5),
        ('Mariscos', '🦞', 6),
        ('Postres', '🍰', 7),
        ('Bebidas', '🥤', 8),
        ('Cocteles', '🍸', 9)
      ON CONFLICT DO NOTHING
      RETURNING id, name
    `);

    const catMap = {};
    cats.rows.forEach(c => catMap[c.name] = c.id);

    // Products
    const products = await client.query(`
      INSERT INTO products (category_id, name, description, price, preparation_time) VALUES
        -- Entradas
        (${catMap['Entradas']}, 'Nachos Supremos', 'Nachos crujientes con queso fundido, jalapeños, guacamole y crema agria', 12.99, 10),
        (${catMap['Entradas']}, 'Alitas BBQ', '8 alitas de pollo con salsa BBQ ahumada o buffalo. Con aderezo ranch', 14.99, 15),
        (${catMap['Entradas']}, 'Calamares Fritos', 'Anillos de calamar en tempura ligera con salsa aioli de limón', 13.99, 12),
        (${catMap['Entradas']}, 'Bruschetta Italiana', 'Pan artesanal tostado con tomate fresco, albahaca y aceite de oliva extra virgen', 9.99, 8),

        -- Hamburguesas
        (${catMap['Hamburguesas']}, 'Classic Burger', 'Carne angus 200g, lechuga, tomate, cebolla, pepinillo y mayonesa. Con papas fritas', 16.99, 18),
        (${catMap['Hamburguesas']}, 'BBQ Bacon Burger', 'Doble carne angus, bacon crujiente, queso cheddar, cebolla caramelizada y salsa BBQ', 19.99, 20),
        (${catMap['Hamburguesas']}, 'Mushroom Swiss', 'Carne angus, hongos salteados, queso suizo, espinacas y salsa de mostaza', 18.99, 18),
        (${catMap['Hamburguesas']}, 'Veggie Burger', 'Hamburguesa de garbanzo y vegetales, aguacate, sprouts y mayonesa vegana', 15.99, 18),
        (${catMap['Hamburguesas']}, 'Tower Burger', 'Triple carne angus, triple queso, bacon, huevo frito, aros de cebolla y salsas especiales', 24.99, 25),

        -- Pizzas
        (${catMap['Pizzas']}, 'Margherita', 'Salsa de tomate San Marzano, mozzarella fior di latte, albahaca fresca', 18.99, 20),
        (${catMap['Pizzas']}, 'Cuatro Quesos', 'Mozzarella, gorgonzola, parmesano y gouda con aceite de trufa', 22.99, 22),
        (${catMap['Pizzas']}, 'Pepperoni Premium', 'Doble pepperoni, mozzarella, orégano y aceite de oliva', 21.99, 20),
        (${catMap['Pizzas']}, 'Prosciutto e Rucola', 'Prosciutto di Parma, rúcula fresca, mozzarella y parmesano', 24.99, 22),

        -- Pastas
        (${catMap['Pastas']}, 'Carbonara Clásica', 'Spaghetti con panceta, yema de huevo, pecorino y pimienta negra', 17.99, 20),
        (${catMap['Pastas']}, 'Penne Arrabiata', 'Penne con salsa de tomate picante, ajo, chile y albahaca', 15.99, 18),
        (${catMap['Pastas']}, 'Fettuccine Alfredo', 'Fettuccine cremoso con queso parmesano, mantequilla y nuez moscada', 16.99, 18),
        (${catMap['Pastas']}, 'Lasaña de la Casa', 'Capas de pasta fresca, boloñesa de res, bechamel y gratinado', 19.99, 25),

        -- Carnes
        (${catMap['Carnes']}, 'Ribeye 300g', 'Corte prime angus con mantequilla de hierbas, papas rústicas y vegetales asados', 38.99, 25),
        (${catMap['Carnes']}, 'New York Strip 250g', 'Corte jugoso a la parrilla con sal de mar, romero y ajo confitado', 34.99, 22),
        (${catMap['Carnes']}, 'Rack de Costillas', 'Costillas BBQ baby back ahumadas 8 horas, puré de papa y ensalada coleslaw', 32.99, 30),
        (${catMap['Carnes']}, 'Pollo a las Brasas', 'Pollo entero en salsa chimichurri, papas al horno y ensalada verde', 24.99, 30),

        -- Mariscos
        (${catMap['Mariscos']}, 'Langosta Termidor', 'Langosta entera gratinada con salsa cremosa de brandy y queso', 55.99, 30),
        (${catMap['Mariscos']}, 'Camarones al Ajillo', 'Camarones jumbo salteados en aceite de oliva, ajo y vino blanco', 28.99, 15),
        (${catMap['Mariscos']}, 'Salmón a la Plancha', 'Filete de salmón noruego con salsa de alcaparras y limón, vegetales al vapor', 26.99, 18),
        (${catMap['Mariscos']}, 'Pulpo a la Gallega', 'Pulpo tierno sobre puré de papa, paprika ahumada y aceite de oliva virgen', 29.99, 20),

        -- Postres
        (${catMap['Postres']}, 'Tiramisú Artesanal', 'Tiramisú tradicional con mascarpone, café espresso y cacao', 8.99, 5),
        (${catMap['Postres']}, 'Coulant de Chocolate', 'Volcán de chocolate belga con centro líquido y helado de vainilla', 9.99, 12),
        (${catMap['Postres']}, 'Cheesecake New York', 'Tarta de queso cremosa con base de galleta y coulis de frutos rojos', 8.99, 5),
        (${catMap['Postres']}, 'Crème Brûlée', 'Crema catalana tradicional con caramelo crujiente y frutos rojos frescos', 7.99, 5),

        -- Bebidas
        (${catMap['Bebidas']}, 'Agua Mineral', 'Agua mineral sin gas 500ml', 2.99, 2),
        (${catMap['Bebidas']}, 'Limonada Natural', 'Limonada fresca exprimida con menta y azúcar de caña', 4.99, 5),
        (${catMap['Bebidas']}, 'Jugos Naturales', 'Naranja, mango, maracuyá o mora. Exprimidos al momento', 5.99, 5),
        (${catMap['Bebidas']}, 'Café Espresso', 'Espresso doble de granos de origen tostado artesanal', 3.99, 5),
        (${catMap['Bebidas']}, 'Té Artesanal', 'Selección de tés premium: Earl Grey, Menta, Manzanilla, Verde', 3.99, 5),

        -- Cocteles
        (${catMap['Cocteles']}, 'Mojito Clásico', 'Ron blanco, lima, menta fresca, azúcar y soda', 10.99, 8),
        (${catMap['Cocteles']}, 'Margarita Premium', 'Tequila reposado, triple sec, lima fresca y sal de mar', 12.99, 8),
        (${catMap['Cocteles']}, 'Old Fashioned', 'Bourbon, azúcar demerara, angostura y twist de naranja', 13.99, 8),
        (${catMap['Cocteles']}, 'Aperol Spritz', 'Aperol, Prosecco, soda y naranja. Verano en copa', 11.99, 5),
        (${catMap['Cocteles']}, 'Negroni', 'Gin, Campari, Vermut Rosso y twist de naranja', 13.99, 8)
      ON CONFLICT DO NOTHING
      RETURNING id, name
    `);

    const prodMap = {};
    products.rows.forEach(p => prodMap[p.name] = p.id);

    // Modifier Groups for burgers
    if (prodMap['Classic Burger']) {
      const g1 = await client.query(`
        INSERT INTO modifier_groups (product_id, name, required, min_select, max_select) VALUES
          (${prodMap['Classic Burger']}, 'Término de cocción', true, 1, 1),
          (${prodMap['Classic Burger']}, 'Ingredientes adicionales', false, 0, 10),
          (${prodMap['Classic Burger']}, 'Cambiar acompañamiento', false, 0, 1)
        RETURNING id, name
      `);

      const [termGroup, extrasGroup, sideGroup] = g1.rows;

      await client.query(`
        INSERT INTO modifiers (group_id, name, price, sort_order) VALUES
          (${termGroup.id}, '3/4 (Medio Crudo)', 0, 1),
          (${termGroup.id}, 'Término Medio', 0, 2),
          (${termGroup.id}, 'Bien Cocido', 0, 3),
          (${extrasGroup.id}, 'Queso Cheddar extra', 1.50, 1),
          (${extrasGroup.id}, 'Queso Suizo extra', 1.50, 2),
          (${extrasGroup.id}, 'Queso Azul extra', 2.00, 3),
          (${extrasGroup.id}, 'Bacon crujiente', 2.50, 4),
          (${extrasGroup.id}, 'Aguacate/Guacamole', 2.00, 5),
          (${extrasGroup.id}, 'Huevo frito', 1.50, 6),
          (${extrasGroup.id}, 'Aros de cebolla', 1.50, 7),
          (${extrasGroup.id}, 'Jalapeños frescos', 1.00, 8),
          (${extrasGroup.id}, 'Champiñones salteados', 1.50, 9),
          (${extrasGroup.id}, 'Doble carne (+200g)', 5.00, 10),
          (${sideGroup.id}, 'Papas fritas (incluidas)', 0, 1),
          (${sideGroup.id}, 'Papas en cuñas', 0, 2),
          (${sideGroup.id}, 'Ensalada verde', 0, 3),
          (${sideGroup.id}, 'Papas con queso (+$1.50)', 1.50, 4),
          (${sideGroup.id}, 'Aros de cebolla (+$2.00)', 2.00, 5)
        ON CONFLICT DO NOTHING
      `);

      // Copy modifier groups to other burgers
      for (const burgerName of ['BBQ Bacon Burger', 'Mushroom Swiss', 'Veggie Burger', 'Tower Burger']) {
        if (prodMap[burgerName]) {
          const g2 = await client.query(`
            INSERT INTO modifier_groups (product_id, name, required, min_select, max_select) VALUES
              (${prodMap[burgerName]}, 'Término de cocción', true, 1, 1),
              (${prodMap[burgerName]}, 'Ingredientes adicionales', false, 0, 10),
              (${prodMap[burgerName]}, 'Cambiar acompañamiento', false, 0, 1)
            RETURNING id, name
          `);
          const [t2, e2, s2] = g2.rows;
          await client.query(`
            INSERT INTO modifiers (group_id, name, price, sort_order) VALUES
              (${t2.id}, '3/4 (Medio Crudo)', 0, 1),
              (${t2.id}, 'Término Medio', 0, 2),
              (${t2.id}, 'Bien Cocido', 0, 3),
              (${e2.id}, 'Queso Cheddar extra', 1.50, 1),
              (${e2.id}, 'Bacon crujiente', 2.50, 2),
              (${e2.id}, 'Aguacate/Guacamole', 2.00, 3),
              (${e2.id}, 'Huevo frito', 1.50, 4),
              (${e2.id}, 'Jalapeños frescos', 1.00, 5),
              (${e2.id}, 'Doble carne (+200g)', 5.00, 6),
              (${s2.id}, 'Papas fritas (incluidas)', 0, 1),
              (${s2.id}, 'Ensalada verde', 0, 2),
              (${s2.id}, 'Papas con queso (+$1.50)', 1.50, 3)
            ON CONFLICT DO NOTHING
          `);
        }
      }
    }

    // Pizza modifier groups
    for (const pizzaName of ['Margherita', 'Cuatro Quesos', 'Pepperoni Premium', 'Prosciutto e Rucola']) {
      if (prodMap[pizzaName]) {
        const pg = await client.query(`
          INSERT INTO modifier_groups (product_id, name, required, min_select, max_select) VALUES
            (${prodMap[pizzaName]}, 'Tamaño', true, 1, 1),
            (${prodMap[pizzaName]}, 'Ingredientes adicionales', false, 0, 5),
            (${prodMap[pizzaName]}, 'Masa', false, 0, 1)
          RETURNING id, name
        `);
        const [sz, ex, ms] = pg.rows;
        await client.query(`
          INSERT INTO modifiers (group_id, name, price, sort_order) VALUES
            (${sz.id}, 'Personal (25cm)', -3.00, 1),
            (${sz.id}, 'Mediana (30cm)', 0, 2),
            (${sz.id}, 'Grande (35cm)', 4.00, 3),
            (${sz.id}, 'Familiar (40cm)', 7.00, 4),
            (${ex.id}, 'Queso extra', 2.00, 1),
            (${ex.id}, 'Pepperoni', 2.50, 2),
            (${ex.id}, 'Champiñones', 1.50, 3),
            (${ex.id}, 'Aceitunas negras', 1.50, 4),
            (${ex.id}, 'Jalapeños', 1.00, 5),
            (${ex.id}, 'Rúcula fresca', 1.50, 6),
            (${ms.id}, 'Masa tradicional', 0, 1),
            (${ms.id}, 'Masa delgada', 0, 2),
            (${ms.id}, 'Masa gruesa', 0, 3),
            (${ms.id}, 'Sin gluten (+$2.00)', 2.00, 4)
          ON CONFLICT DO NOTHING
        `);
      }
    }

    // Steak modifier groups
    for (const steakName of ['Ribeye 300g', 'New York Strip 250g']) {
      if (prodMap[steakName]) {
        const sg = await client.query(`
          INSERT INTO modifier_groups (product_id, name, required, min_select, max_select) VALUES
            (${prodMap[steakName]}, 'Término', true, 1, 1),
            (${prodMap[steakName]}, 'Salsa', false, 0, 1),
            (${prodMap[steakName]}, 'Acompañamiento extra', false, 0, 2)
          RETURNING id, name
        `);
        const [tr, sc, ac] = sg.rows;
        await client.query(`
          INSERT INTO modifiers (group_id, name, price, sort_order) VALUES
            (${tr.id}, 'Azul (Blue)', 0, 1),
            (${tr.id}, 'Poco Hecho (Rare)', 0, 2),
            (${tr.id}, '3/4 (Medium Rare)', 0, 3),
            (${tr.id}, 'Al Punto (Medium)', 0, 4),
            (${tr.id}, 'Bien Hecho (Well Done)', 0, 5),
            (${sc.id}, 'Pimienta negra', 0, 1),
            (${sc.id}, 'Chimichurri', 0, 2),
            (${sc.id}, 'Mantequilla de hierbas', 0, 3),
            (${sc.id}, 'Vino tinto reducción', 0, 4),
            (${ac.id}, 'Papas gratinadas (+$3)', 3.00, 1),
            (${ac.id}, 'Vegetales a la parrilla', 0, 2),
            (${ac.id}, 'Ensalada cesar (+$2)', 2.00, 3)
          ON CONFLICT DO NOTHING
        `);
      }
    }

    // Tables
    await client.query(`
      INSERT INTO tables (number, capacity, status, location) VALUES
        ('1', 2, 'available', 'Terraza'),
        ('2', 2, 'available', 'Terraza'),
        ('3', 4, 'available', 'Terraza'),
        ('4', 4, 'available', 'Salón'),
        ('5', 4, 'available', 'Salón'),
        ('6', 4, 'available', 'Salón'),
        ('7', 6, 'available', 'Salón'),
        ('8', 6, 'available', 'Salón'),
        ('9', 8, 'available', 'Salón'),
        ('10', 8, 'available', 'Salón'),
        ('11', 2, 'available', 'Barra'),
        ('12', 2, 'available', 'Barra'),
        ('VIP-1', 6, 'available', 'VIP'),
        ('VIP-2', 8, 'available', 'VIP'),
        ('VIP-3', 10, 'available', 'VIP')
      ON CONFLICT (number) DO NOTHING
    `);

    await client.query('COMMIT');
    console.log('✅ Database seeded successfully');
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('❌ Seed failed:', err);
    throw err;
  } finally {
    client.release();
    await pool.end();
  }
}

seed().catch(console.error);

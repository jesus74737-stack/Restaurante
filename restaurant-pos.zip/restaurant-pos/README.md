# 🍽️ Noir & Gold — Sistema POS para Restaurante

Sistema POS completo con diseño elegante negro y dorado. Incluye menú interactivo, gestión de mesas, órdenes en tiempo real, pantalla de cocina, pagos y reportes.

## ✨ Características

| Módulo | Funcionalidades |
|--------|----------------|
| 🗺️ **Mesas** | Mapa visual, estados en tiempo real, filtro por zona |
| 🍔 **Menú** | Categorías, productos, modificadores/ingredientes con precio, búsqueda |
| 🛒 **Pedidos** | Carrito, notas por ítem, envío a cocina |
| 💳 **Pagos** | Efectivo, tarjeta, transferencia, mixto, propinas, cambio |
| 🔥 **Cocina** | Pantalla KDS en tiempo real, prioridad por tiempo, avanzar estados |
| 📋 **Órdenes** | Lista completa, filtros por estado, flujo de estados |
| 📊 **Reportes** | Ventas diarias, por hora, productos top, tendencia semanal |
| ⚙️ **Admin** | Gestión de productos y categorías, activar/desactivar |

## 🚀 Configuración y despliegue

### 1. Clonar el repositorio

```bash
git clone https://github.com/tu-usuario/restaurant-pos.git
cd restaurant-pos
```

### 2. Configurar base de datos en Railway

1. Ve a [railway.app](https://railway.app) y crea una cuenta
2. Crea un nuevo proyecto → **Add Service** → **PostgreSQL**
3. Copia la variable `DATABASE_URL` desde la pestaña **Variables**

### 3. Variables de entorno

Crea `server/.env` basándote en `server/.env.example`:

```env
DATABASE_URL=postgresql://...  # De Railway
PORT=4000
NODE_ENV=development
CLIENT_URL=http://localhost:5173
```

### 4. Instalar dependencias

```bash
npm run install:all
```

### 5. Migrar y poblar la base de datos

```bash
cd server
node db/migrate.js    # Crea las tablas
node db/seed.js       # Carga el menú de ejemplo (9 categorías, 38 productos)
cd ..
```

### 6. Correr en desarrollo

```bash
npm run dev
# Frontend: http://localhost:5173
# Backend:  http://localhost:4000
```

---

## ☁️ Despliegue en Railway (producción)

### Opción A: Deploy automático desde GitHub

1. Push tu código a GitHub
2. En Railway: **New Project** → **Deploy from GitHub repo**
3. Selecciona el repositorio
4. Railway detecta `railway.toml` automáticamente
5. Agrega las variables de entorno:
   - `DATABASE_URL` (conecta el servicio PostgreSQL)
   - `NODE_ENV=production`
6. Haz deploy → Railway construye y despliega

### Opción B: Railway CLI

```bash
npm install -g @railway/cli
railway login
railway init
railway add postgresql
railway variables set NODE_ENV=production
railway up
```

### Post-deploy: migrar base de datos

En Railway, abre la consola del servicio y ejecuta:
```bash
node server/db/migrate.js
node server/db/seed.js
```

---

## 🛠️ Stack tecnológico

**Frontend**
- React 18 + Vite
- Tailwind CSS (tema negro y dorado personalizado)
- Socket.io-client (tiempo real)
- Recharts (gráficas de reportes)
- React Router v6

**Backend**
- Node.js + Express
- Socket.io (WebSockets)
- PostgreSQL + node-postgres (pg)

**Infraestructura**
- Railway (hosting + PostgreSQL)
- GitHub (repositorio)

---

## 📁 Estructura del proyecto

```
restaurant-pos/
├── client/                # Frontend React
│   ├── src/
│   │   ├── pages/         # TablesPage, MenuPage, CheckoutPage...
│   │   ├── context/       # SocketContext, OrderContext
│   │   └── utils/api.js   # Llamadas a la API
│   └── vite.config.js
├── server/                # Backend Express
│   ├── routes/            # categories, products, tables, orders, reports
│   ├── db/                # migrate.js, seed.js
│   └── config/database.js
├── railway.toml           # Config de despliegue
└── package.json
```

## 🎨 Diseño

- **Tipografía**: Playfair Display (títulos) + Outfit (cuerpo)
- **Colores**: Negro profundo `#0A0A0A` + Dorado `#D4AF37`
- **Responsive**: Mobile, tablet y desktop
- **Tiempo real**: Socket.io para actualización de órdenes y mesas

## 📱 Pantallas

1. **Mesas** — Selección visual con estado en tiempo real
2. **Menú** — Grid de productos con modificadores en modal
3. **Checkout** — Confirmación → Cocina → Pago
4. **Cocina** — KDS con prioridad por tiempo y colores de urgencia
5. **Órdenes** — Vista completa con filtros y flujo de estados
6. **Reportes** — Dashboard con gráficas diarias y semanales
7. **Admin** — CRUD de productos y categorías
